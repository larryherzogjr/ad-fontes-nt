---
title: "Haima (αἷμα)"
linkTitle: "Haima"
greek: "αἷμα"
translit: "Haima"
pronunciation: "HIGH-mah"
subhead: "the new covenant in My blood"
gloss: "blood"
volume: 1
access: "free"
slug: "haima"
description: "Haima (αἷμα), \"blood\" — a New Testament Greek word study: meaning, range, where you meet it in Scripture, and what confessional Lutherans hear."
draft: false
category: "Christ and His Work"
tags: ["sacrament", "atonement"]
source: "Just Enough Greek"
source_part: "Part IV \u00b7 The Means of Grace"
source_order: 33
editorial_review: "approved"
editorial_approval_date: "2026-09-09"
editorial_previous_approval_date: "2026-09-08"
editorial_revision_date: "2026-09-09"
draft_copy: false
editorial_revision: "Standalone framing and article links; approved by Larry Herzog Jr. on 2026-09-09"
---

<!-- AD FONTES BSB ADAPTATION: pending Larry Herzog Jr. review; the original website edition is unchanged. -->

There is a verse in Leviticus that most modern Christians have never carefully read, but that the New Testament writers had memorized.

“For the life of the flesh is in the blood, and I have given it to you to make atonement for your souls upon the altar; for it is the blood that makes atonement for the soul.” (Leviticus 17:11, BSB)

Three ideas are concentrated in one verse, and the New Testament’s theology of blood is built on all three. Blood is life. Blood is given by God Himself for atonement. The blood works atonement because it carries the life — the life given in exchange for the life forfeited by sin. This is the conceptual structure behind every New Testament use of the Greek word for blood — *haima* — in connection with the cross, the atonement, and the Lord’s Supper.

When Christ took the cup at the Last Supper and said, “saying, ‘This cup is the new covenant in My blood, which is poured out for you’” — *touto to potērion hē kainē diathēkē en tō haimati mou* — He was reaching for a structure of sacrificial-covenantal blood-theology that ran from Leviticus through Exodus 24 through the prophets to the cross He was about to bear. The blood would be poured out at Calvary the following day. The blood would now be given in the cup for His church to drink as long as the world stands.

This entry covers *haima*, the blood. The related entries on [Soma](/greek/soma/) and [Artos](/greek/artos/) cover the body and the bread, while [Koinonia](/greek/koinonia/) explores the communion they create. Together these studies describe what happens at the table where Christ is given.

## The Word

**αἷμα** (haima), pronounced *HIGH-mah*. A neuter noun, third declension. The family includes the verb *haimorrhoeō* (αἱμορροέω, “to suffer a flow of blood, to hemorrhage” — used of the woman in Matthew 9:20) and the noun *haimatekchysia* (αἱματεκχυσία, “shedding of blood” — used only at Hebrews 9:22). The English word *hematology* descends from this Greek root, and to a Greek ear *haima* was the ordinary word for the red substance in veins, whether human or animal.

The lexical field is wide. *Haima* in ordinary Greek usage covered:

- Physical blood, in human or animal bodies.
- The blood of sacrificial victims, especially in religious contexts.
- Blood as the substance of life — the carrier of life-force, on the common ancient view.
- Kinship and family connection — “of one blood” as the standard idiom for shared descent.
- Bloodshed and violence — the language of killing.

The New Testament inherits this whole range and adds a specific theological deployment: the blood of Christ. The dominant New Testament use of *haima* is the blood Christ shed at the cross and the blood Christ gives in the cup of the Supper. Theologically, these are not two bloods. They are one blood, with one source (Christ Himself), one purpose (atonement), and two locations of delivery (the cross historically, the cup sacramentally).

The Old Testament background is essential. Leviticus 17:11 is the most concentrated statement: blood is the bearer of life; blood is given by God for atonement; the blood atones because it carries the life. The entire Old Testament sacrificial system depends on this theology. The Day of Atonement blood (Lev 16). The Passover blood on the doorposts (Exod 12). The covenant blood Moses sprinkled on the people at Sinai (Exod 24:6–8 — “Moses took half of the blood and put it in bowls, and the other half he splattered on the altar. Then he took the Book of the Covenant and read it to the people, who replied, ‘All that the LORD has spoken we will do, and we will be obedient.’ So Moses took the blood, splattered it on the people, and said, ‘This is the blood of the covenant that the LORD has made with you in accordance with all these words’”). The peace offerings, the sin offerings, the guilt offerings. Blood at every turn. The Old Testament had a system in which sin required death, the death of the sinner was averted by the death of a substitute, and the blood of the substitute was the means by which the substitution was applied.

The New Testament’s *haima* picks up this entire structure and applies it to Christ. Christ is the once-for-all sacrifice (Hebrews — see [Anamnēsis](/greek/anamnesis/)); His blood is the blood of the new covenant (the institution words); His blood propitiates the wrath of God against sin ([Hilastērion](/greek/hilasterion/)); His blood is the means by which the new covenant ([Diathēkē](/greek/diatheke/)) is ratified. Every New Testament use of *haima* in connection with the cross is reading off the Levitical theology of blood-as-life-given-for-atonement.

## Range of Meaning

In its New Testament usage, *haima* covers:

- Physical blood, in ordinary medical or descriptive contexts. The woman with the flow of blood (Mark 5:25), Pilate washing his hands of innocent blood (Matt 27:24), the field of blood (Acts 1:19).
- Bloodshed and violence. The blood of the prophets, the blood of innocent martyrs, the blood-guilt of nations.
- The sacrificial blood of Old Testament victims. Hebrews 9 and 10 use *haima* extensively in this connection.
- The blood of Christ. The dominant theological use, covering several distinct but related dimensions: sacrificial (the propitiating, atoning blood), covenantal (the blood that ratifies the new covenant), cleansing (the blood that washes from sin), redemptive (the blood that purchases the slaves of sin), eschatologically victorious (the blood by which the saints overcome — Rev 12:11).
- The blood of Christ in the Supper. The institution words and 1 Corinthians 10:16, 11:25–29.

The last two senses are not separate. The blood given in the cup is the same blood that was shed on the cross. The Supper does not produce additional blood; the Supper delivers the once-shed blood to the participant. This is the same logic that ran through [Anamnēsis](/greek/anamnesis/): the once-for-all sacrifice is made present at the table; the historical event is delivered through the means Christ instituted.

## Where You’ll Meet It

> “He said to them, ‘This is My blood of the covenant, which is poured out for many.’” (Mark 14:24, BSB)

The shortest of the institution sayings on the blood. Mark’s version. The verb is the same *estin* that ran through the [Sōma](/greek/soma/) entry. *This is my blood of the covenant.* The cup contains the blood. The blood is covenantal — the blood that seals the new diathēkē Christ is establishing. The “poured out for many” anticipates the cross of the following day. The same blood that will be poured out at Calvary is the blood being given in the cup at the table the night before.

> “This is My blood of the covenant, which is poured out for many for the forgiveness of sins.” (Matthew 26:28, BSB)

Matthew’s version, which adds the explicit purpose: *for the forgiveness of sins*. The connection to [*aphesis*](/greek/aphesis/) is direct. The blood is the means; the forgiveness is the purpose; the cup is the delivery. The Supper carries the forgiveness Christ won at Calvary into the mouth of the believer at the table.

> “In the same way, after supper He took the cup, saying, ‘This cup is the new covenant in My blood, which is poured out for you.’” (Luke 22:20, BSB)

Luke’s version. The “for you” — *hyper humōn* — connects to [Hyper](/greek/hyper/). The cup is poured out *for you* specifically. The new covenant is *in my blood*. Luke joins what some traditions have tried to separate: the cup, the pouring out, the substitution, the covenant, the blood. All in one verse, all in the present tense of the table.

> “Is not the cup of blessing that we bless a participation in the blood of Christ? And is not the bread that we break a participation in the body of Christ? Because there is one loaf, we who are many are one body; for we all partake of the one loaf.” (1 Corinthians 10:16–17, BSB)

Paul’s interpretation. Treated in the [Sōma](/greek/soma/) entry, but the cup-blood pair deserves its own attention here. *Koinōnia* — participation, sharing, communion — names what the cup does. The cup is a *a sharing in the blood of Christ*. Not a symbol of the blood. Not a memorial of an absent blood. A participation, a sharing-in, an actual partaking of the blood of the one who shed it for us. This will return in [Koinōnia](/greek/koinonia/); for now, the connection between the cup and the blood is direct and material.

> “Therefore, whoever eats the bread or drinks the cup of the Lord in an unworthy manner will be guilty of sinning against the body and blood of the Lord.” (1 Corinthians 11:27, BSB)

The warning text, treated also in the [Sōma](/greek/soma/) entry. Worth quoting here for the *blood* side. The unworthy participant is guilty concerning the *body and blood* of the Lord. The blood is there. The unworthy drink it. The seriousness of the warning depends on the blood actually being present. If the cup were merely wine with symbolic significance, “guilty of sinning against the body and blood of the Lord” would lose its weight. The Lutheran reading: the blood is present; the cup contains what Christ said it contains; the warning is exactly as serious as Paul makes it.

> “In Him we have redemption through His blood, the forgiveness of our trespasses, according to the riches of His grace” (Ephesians 1:7, BSB)

The wider Pauline blood-theology. Redemption is *through his blood*. The forgiveness is the substance of the redemption. The grace is the source. Every Pauline blood-passage runs this same structure: blood is the means; salvation in some specific dimension (justification, redemption, propitiation, reconciliation, forgiveness, peace) is the result; grace is the source.

> “But now in Christ Jesus you who once were far away have been brought near through the blood of Christ.” (Ephesians 2:13, BSB)

The relational dimension. The blood brings near. The believer who was far off — outside the covenant people, alienated from God — has been brought near *by the blood*. The blood is not only the means of atonement (transactional) but the means of incorporation (relational). The same blood that paid the price brings the bought one into the family.

> “According to the law, in fact, nearly everything must be purified with blood, and without the shedding of blood there is no forgiveness.” (Hebrews 9:22, BSB)

The sober verse. Hebrews makes the Levitical theology of blood absolutely explicit. *Without the shedding of blood there is no forgiveness.* The verb is *haimatekchysia* — “shedding of blood,” the noun built directly from *haima*. The author of Hebrews has been arguing throughout [Doxa](/greek/doxa/), [Hamartia](/greek/hamartia/), [Sarx](/greek/sarx/) that the old covenant’s sacrificial system pointed to and was fulfilled in Christ’s once-for-all sacrifice. The principle remains: forgiveness requires blood. Christ’s blood was the cost. The cup is the delivery.

## What Confessional Lutherans Hear

Two things ring in Lutheran ears when we hear *haima*.

First, Christ’s true blood is really, substantially present in the cup at the Lord’s Supper. The Lutheran position on the cup is the same as the Lutheran position on the bread, established in the [Sōma](/greek/soma/) entry. The institution words are the same kind of identity-statement: “this is My blood of the covenant, which is poured out for many.” The verb is *estin*. The cup contains what Christ said the cup contains.

This is treated more fully in the [Sōma](/greek/soma/) entry, and the Lutheran arguments are the same: the institution words refuse the Memorialist reduction; the Reformed location of Christ’s blood in heaven (with spiritual communion only at the cup) is not what the institution words say; the Roman transubstantiation is unnecessary metaphysical apparatus; the Lutheran *sacramental union* affirms that the wine remains wine while Christ’s blood is given in, with, and under it. The same sacramental logic; the same Word-grounded presence; the same warning of unworthy reception (1 Cor 11:27 — guilty concerning the body *and blood*); the same comfort for the believer who comes in faith.

One specific application matters here that the [Sōma](/greek/soma/) entry did not develop. The medieval Roman practice of withholding the cup from the laity — offering only the bread to communicants, with the priest receiving both elements at the altar — was one of the practices the Lutheran Reformation rejected with particular vigor. The Latin term for the medieval restriction was *communio sub una specie* (communion in one kind only). Christ instituted communion in *both* kinds — bread and cup — and commanded “drink from it, all of you” (Matthew 26:27, BSB). The Lutheran insistence on *communio sub utraque specie* (communion in both kinds, bread and cup, for all communicants) was a return to the practice Christ commanded. Contemporary Roman Catholic practice has substantially restored the cup to the laity in many settings, but the historical Reformation dispute was substantive, and the Lutheran restoration of the cup is one of the practices the Lutheran tradition has retained without revisitation.

Second, the blood is the new covenant — the blood that ratifies the *diathēkē*. The connection to [Diathēkē](/greek/diatheke/) is direct. The institution words name the cup as “the new covenant in My blood, which is poured out for you.” The blood is what makes the covenant operative. The same blood was at work in the Sinai covenant (Exod 24:6–8 — “Moses took half of the blood and put it in bowls, and the other half he splattered on the altar. Then he took the Book of the Covenant and read it to the people, who replied, ‘All that the LORD has spoken we will do, and we will be obedient.’ So Moses took the blood, splattered it on the people, and said, ‘This is the blood of the covenant that the LORD has made with you in accordance with all these words’”), where Moses sprinkled the blood of bulls on the people and pronounced the covenant active. The new covenant is ratified the same way — with blood — but with Christ’s blood, once-for-all, given in the cup as the abiding pledge of the covenant He has established.

This is one of the dimensions of the Supper that confessional Lutheran preaching emphasizes consistently. The Supper is not merely a fellowship meal with theological significance; it is the new covenant’s covenantal meal. The participant in the cup is the participant in the covenant. The blood that ratified the covenant is the blood that is being received. The forgiveness the covenant promises is the forgiveness the cup delivers. The relationship the covenant establishes is the relationship the participation in the blood maintains.

The pastoral payoff: when you drink the cup at the Supper, you are drinking the blood of the new covenant. The blood that purchased your redemption. The blood that ratifies God’s promise to you. The blood that cleanses you from sin (1 John 1:7). The blood that brings you near (Eph 2:13). The blood that gives confidence to enter the holy place (Heb 10:19). The blood that the cross poured out is the blood the cup pours into your mouth. The same source. The same Christ. The same blood. The same salvation, delivered weekly, by the means He instituted, for as long as you have breath to swallow.

## Where People Get It Wrong

Three common ways.

The first is the Memorialist or Reformed reduction of the cup, parallel to the reduction of the bread treated in the [Sōma](/greek/soma/) entry. The cup is just wine; the blood is in heaven or in the cross only; the cup is symbolic. The Lutheran response is the same: the institution words refuse this; *estin* means *is*; Paul’s warning in 1 Cor 11:27 requires the blood to actually be there. The Lutheran reading of the cup is consistent with the Lutheran reading of the bread, on the same Scriptural and grammatical grounds.

The second is the modern aversion to “blood” language. Some contemporary preaching, particularly in mainline Protestant settings, treats blood-language as primitive, gory, off-putting to modern sensibilities, or theologically embarrassing. The result is sermons on Christ’s death that avoid the word “blood” or use it apologetically. The Lutheran response: the blood is central to the New Testament’s actual theology of salvation. *Without the shedding of blood there is no forgiveness* (Heb 9:22). The blood is what the New Testament gives us, and the New Testament will not be improved by being made less bloody. The forgiveness the believer receives weekly in the cup was costly; the cost was blood; the blood is in the cup; this is what the gospel actually is. Modern squeamishness about blood is not a refinement of the faith; it is a thinning of the faith.

The third is the blood-as-magical-substance over-reach. Some traditions, particularly in some evangelical and Pentecostal streams, speak of “the blood of Jesus” as if it were a power-substance separable from the person of Christ — a magical agent invoked for protection, healing, or spiritual warfare apart from Christ Himself. The Lutheran response: the blood is Christ’s blood; the power is Christ’s; the blood works because Christ works through it. The blood is not a free-standing spiritual force; the blood is the costly life of the Savior given for the salvation of sinners. To invoke “the blood” apart from invoking Christ is to truncate the doctrine. The blood does what it does because Christ shed it, and the Christ who shed it is the Christ who gives it in the cup.

## So What

When you drink the cup at the Supper, you are drinking the blood of the new covenant. The blood that was shed for the forgiveness of your sins. The blood that ratifies God’s promise to you. The blood that brings you near to God. The blood that the cross poured out is the blood the cup pours into your mouth. The covenant is sealed. The forgiveness is given. The Christ who shed His blood for you gives that blood to you, weekly, for the rest of your life.

For Sunday school teachers and Bible study leaders: when you teach a passage with blood-language, anchor it in Leviticus 17:11. The Old Testament theology of blood-as-life-given-for-atonement is what the New Testament is building on. Without the Old Testament roots, the New Testament’s blood-language becomes either thin (modern reduction) or distorted (blood as separable power-substance). Help your students see the consistent biblical theology of blood across both testaments. The blood that flowed at the cross is the blood that flows in the cup. The blood that flows in the cup is the blood Leviticus prepared the way for. The whole biblical theology of sacrifice, covenant, atonement, and forgiveness runs through the *haima* of Christ.

For yourself: when you next receive the cup, listen for the words. “The blood of Christ, shed for you.” This is the blood Christ shed at Calvary. This is the blood that paid for your sins. This is the blood given to you weekly, in the cup, for the forgiveness of your sins. The new covenant was sealed in this blood, and you are a participant in it. The Christ who shed the blood is the Christ who gives the blood. The blood that bought you continues to nourish you. The Supper is His promise applied in your mouth.
