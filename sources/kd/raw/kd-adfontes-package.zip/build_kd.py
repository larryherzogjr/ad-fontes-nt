#!/usr/bin/env python3
"""Build the Keil & Delitzsch OT commentary dataset from the pulled Logos
articles (kd-articles.jsonl).

Position model: text is reconstructed per article (HTML stripped); paragraph
and milestone positions live in this reconstructed stream. TOC/indexedOffset
values are converted into stream space by interpolating between the
offset markers (<span data-offset=N>) that Logos embeds every ~200 source
characters.

Chapters: chapter C of bible book B starts at the first milestone at/after
the previous chapter's anchor that begins exactly at B.C.1 (single verse or
range start); if none, the first range milestone containing B.C.1. Chapter 1
includes the book introduction (front-matter-in-chapter-1 convention, same
as the Lenski dataset). Volumes covering two OSIS books (Samuel, Kings,
Chronicles) split at the second book's 1:1 anchor. Volume front matter and
the three general introductions attach to the following volume's first
book, chapter 1.
"""
import bisect
import html as htmllib
import json
import re
from pathlib import Path

WS = Path("/Users/lherzog/Documents/kimi/tasks/2026-10-08/11-17-29-e2ed6567")
ATTRIB = ("C. F. Keil and F. Delitzsch, Commentary on the Old Testament "
          "(Edinburgh: T. & T. Clark, 1864–1891). Public domain.")

BOOKS = [
    ("GEN", 1, "Genesis", 50), ("EXO", 2, "Exodus", 40),
    ("LEV", 3, "Leviticus", 27), ("NUM", 4, "Numbers", 36),
    ("DEU", 5, "Deuteronomy", 34), ("JOS", 6, "Joshua", 24),
    ("JDG", 7, "Judges", 21), ("RUT", 8, "Ruth", 4),
    ("1SA", 9, "1 Samuel", 31), ("2SA", 10, "2 Samuel", 24),
    ("1KI", 11, "1 Kings", 22), ("2KI", 12, "2 Kings", 25),
    ("1CH", 13, "1 Chronicles", 29), ("2CH", 14, "2 Chronicles", 36),
    ("EZR", 15, "Ezra", 10), ("NEH", 16, "Nehemiah", 13),
    ("EST", 17, "Esther", 10), ("JOB", 18, "Job", 42),
    ("PSA", 19, "Psalms", 150), ("PRO", 20, "Proverbs", 31),
    ("ECC", 21, "Ecclesiastes", 12), ("SNG", 22, "Song of Songs", 8),
    ("ISA", 23, "Isaiah", 66), ("JER", 24, "Jeremiah", 52),
    ("LAM", 25, "Lamentations", 5), ("EZK", 26, "Ezekiel", 48),
    ("DAN", 27, "Daniel", 12), ("HOS", 28, "Hosea", 14),
    ("JOL", 29, "Joel", 3), ("AMO", 30, "Amos", 9),
    ("OBA", 31, "Obadiah", 1), ("JON", 32, "Jonah", 4),
    ("MIC", 33, "Micah", 7), ("NAM", 34, "Nahum", 3),
    ("HAB", 35, "Habakkuk", 3), ("ZEP", 36, "Zephaniah", 3),
    ("HAG", 37, "Haggai", 2), ("ZEC", 38, "Zechariah", 14),
    ("MAL", 39, "Malachi", 4),
]

VOLUMES = [
    ("Title Page", ["GEN"]), ("Publisher’s Preface", ["GEN"]),
    ("Preface", ["GEN"]),
    ("The First Book of Moses (Genesis)", ["GEN"]),
    ("The Second Book of Moses (Exodus)", ["EXO"]),
    ("The Third Book of Moses (Leviticus)", ["LEV"]),
    ("The Fourth Book of Moses (Numbers)", ["NUM"]),
    ("The Fifth Book of Moses (Deuteronomy)", ["DEU"]),
    ("Introduction to the Prophetical Histories of the Old Testament", ["JOS"]),
    ("The Book of Joshua", ["JOS"]),
    ("The Book of Judges", ["JDG"]),
    ("The Book of Ruth", ["RUT"]),
    ("The Books of Samuel", ["1SA", "2SA"]),
    ("The Books of Kings", ["1KI", "2KI"]),
    ("1 And 2 Chronicles", ["1CH", "2CH"]),
    ("The Book of Ezra", ["EZR"]),
    ("The Book of Nehemiah", ["NEH"]),
    ("The Book of Esther", ["EST"]),
    ("The Book of Job", ["JOB"]),
    ("The Psalter", ["PSA"]),
    ("The Book of Proverbs", ["PRO"]),
    ("The Book of Ecclesiastes", ["ECC"]),
    ("The Song of Songs", ["SNG"]),
    ("Introduction to the Prophetical Books of the Old Testament", ["ISA"]),
    ("The Prophecies of Isaiah", ["ISA"]),
    ("The Prophecies of Jeremiah", ["JER"]),
    ("The Lamentations of Jeremiah", ["LAM"]),
    ("The Prophecies of Ezekiel", ["EZK"]),
    ("Daniel", ["DAN"]),
    ("Introduction to the Twelve Minor Prophets", ["HOS"]),
    ("Hosea", ["HOS"]), ("Joel", ["JOL"]), ("Amos", ["AMO"]),
    ("Obadiah", ["OBA"]), ("Jonah", ["JON"]), ("Micah", ["MIC"]),
    ("Nahum", ["NAM"]), ("Habakkuk", ["HAB"]), ("Zephaniah", ["ZEP"]),
    ("Haggai", ["HAG"]), ("Zechariah", ["ZEC"]), ("Malachi", ["MAL"]),
]

MILESTONE_RE = re.compile(r'<a\b[^>]*rel="milestone"[^>]*?>.*?</a>', re.S)
# machine refs come in several shapes:
#   bible+bhs.B.C.V   bible+bhs.B.C   bible+bhs.B.C-B.C  bible+bhs.B.C.V-B.C.V++
REF_PART_RE = re.compile(
    r'(?:data-raw-reference|data-reference)="(bible\+bhs\.[^"]+)"')


def parse_bhs_ref(ref):
    """'bible+bhs.26.1.3-26.1.28' / 'bible+bhs.26.1-26.32' /
    'bible+bhs.12.24.14++' -> (b, c1, v1, c2, v2) or None."""
    body = ref[len("bible+bhs."):]
    ff = body.endswith("++")
    if ff:
        body = body[:-2]
    if "-" in body:
        s, e = body.split("-", 1)
    else:
        s, e = body, None

    def side(x, is_start):
        p = x.split(".") if x else []
        try:
            p = [int(v) for v in p if v != ""]
        except ValueError:
            return None
        if not p or len(p) > 3:
            return None
        b = p[0]
        c = p[1] if len(p) >= 2 else (1 if is_start else 999)
        v = p[2] if len(p) >= 3 else (1 if is_start else 999)
        return b, c, v
    st = side(s, True)
    if st is None:
        return None
    b, c1, v1 = st
    if e:
        en = side(e, False)
        if en is None or en[0] != b:
            return None
        _, c2, v2 = en
    else:
        c2, v2 = c1, (999 if ff else v1)
    if ff:
        v2 = 999
    return b, c1, v1, c2, v2
OFFSET_MARKER_RE = re.compile(
    r'<span\b[^>]*class="offset-marker"[^>]*data-offset="(\d+)"[^>]*></span>')


def article_to_text(h):
    """HTML -> (text, milestones, offset-markers).

    milestones: [(text_pos, b, c1, v1, c2, v2)] (bible+bhs only)
    markers:    [(text_pos, indexed_offset)] interpolation anchors."""
    miles, markers = [], []

    def mile_sub(m):
        tag = m.group(0)
        mm = REF_PART_RE.search(tag)
        parsed = parse_bhs_ref(mm.group(1)) if mm else None
        if parsed:
            b, c1, v1, c2, v2 = parsed
            inner = ""
            end = tag.rfind("</a")
            if end != -1:
                inner = re.sub(r"<[^>]+>", "", tag[tag.find(">") + 1:end])
            idx = len(miles)
            miles.append((b, c1, v1, c2, v2))
            return "\x00M%d\x00%s" % (idx, inner)
        return ""

    h = MILESTONE_RE.sub(mile_sub, h)

    def mark_sub(m):
        markers.append(int(m.group(1)))
        return "\x00K%d\x00" % (len(markers) - 1)

    h = OFFSET_MARKER_RE.sub(mark_sub, h)
    h = re.sub(r"</p>", "\n\n", h, flags=re.I)
    h = re.sub(r"<p\b[^>]*>", "", h, flags=re.I)
    h = re.sub(r"<(div|br)\b[^>]*>", "\n", h, flags=re.I)
    h = re.sub(r"<[^>]+>", "", h)
    text = htmllib.unescape(h)
    out_m, out_k = [], []
    for i, (b, c1, v1, c2, v2) in enumerate(miles):
        ph = "\x00M%d\x00" % i
        p = text.find(ph)
        out_m.append((p, b, c1, v1, c2, v2))
        text = text.replace(ph, "")
    for i, off in enumerate(markers):
        ph = "\x00K%d\x00" % i
        p = text.find(ph)
        out_k.append((p, off))
        text = text.replace(ph, "")
    return text, out_m, out_k


def main():
    articles = [json.loads(l) for l in
                open(WS / "kd-articles.jsonl", encoding="utf-8")]
    toc = [json.loads(l) for l in
           open(WS / "kd-toc-tree.jsonl", encoding="utf-8")]
    starts = {e["title"]: e["off"] for e in toc if e["level"] == 1}

    pieces, miles, art_spans, marker_map = [], [], [], {}
    pos = 0
    for a in articles:
        text, ms, ks = article_to_text(a["html"])
        for m in ms:
            miles.append((pos + m[0],) + m[1:])
        marker_map[a["id"]] = [(pos + p, off) for p, off in ks]
        art_spans.append((pos, pos + len(text), a["id"], a["off"], a["len"]))
        pieces.append(text)
        pos += len(text)
    stream = "".join(pieces)
    print(f"stream: {len(stream)} chars, milestones: {len(miles)}")

    # indexedOffset -> stream position via per-article marker interpolation
    def to_stream(x):
        lo, hi = 0, len(art_spans) - 1
        while lo < hi:  # find article whose indexed range contains x
            mid = (lo + hi + 1) // 2
            if art_spans[mid][3] <= x:
                lo = mid
            else:
                hi = mid - 1
        base, _, aid, aoff, alen = art_spans[lo]
        if not (aoff <= x < aoff + alen):
            if lo == len(art_spans) - 1 and x >= aoff + alen:
                return len(stream)  # resource-end sentinel
            return None
        ks = marker_map[aid]
        if not ks:  # no markers (tiny articles): scale by length ratio
            return base + int((x - aoff) / max(alen, 1)
                              * (art_spans[lo][1] - base))
        tpos = [k[0] for k in ks]
        i = bisect.bisect_right(tpos, base + (x - aoff))  # approx; refine:
        # find marker pair straddling x by offset value
        offs = [k[1] for k in ks]
        j = bisect.bisect_right(offs, x) - 1
        if j < 0:
            j = 0
        if j >= len(ks) - 1:
            j = max(0, len(ks) - 2)
        (t1, o1), (t2, o2) = ks[j], ks[j + 1]
        if o2 == o1:
            return t1
        return t1 + (x - o1) / (o2 - o1) * (t2 - t1)

    vols = []
    ordered = [(t, bs) for t, bs in VOLUMES if t in starts]
    for i, (t, bs) in enumerate(ordered):
        end = (starts[ordered[i + 1][0]] if i + 1 < len(ordered)
               else 1611413 + 25807633)
        s, e = to_stream(starts[t]), to_stream(end)
        vols.append({"title": t, "books": bs, "start": s, "end": e})
    book_vol = {}
    for v in vols:
        for b in v["books"]:
            book_vol.setdefault(b, v)

    def para_break_before(p):
        q = stream.rfind("\n\n", 0, int(p) + 1)
        return q if q != -1 else int(p)

    anchors = {}
    for osis, bnum, name, nchap in BOOKS:
        vol = book_vol[osis]
        cand = sorted([m for m in miles
                       if m[1] == bnum and m[0] >= vol["start"]])
        got, prev = {}, vol["start"]
        for c in range(1, nchap + 1):
            # P1: milestone starting exactly at C:1; P2: starting in chapter C;
            # P3: section spanning into C. Smallest pos >= prev wins per level.
            p = None
            for pred in (lambda m: m[2] == c and m[3] == 1,
                         lambda m: m[2] == c,
                         lambda m: m[2] < c <= m[4]):
                hit = [m[0] for m in cand if pred(m) and m[0] >= prev]
                if hit:
                    p = min(hit)
                    break
            if p is None:
                print(f"    WARN {osis} ch{c}: no milestone anchor")
                continue
            got[c] = p
            prev = p
        anchors[osis] = got
        missing = [c for c in range(1, nchap + 1) if c not in got]
        if missing:
            print(f"  WARN {osis}: no anchor for chapters {missing}")

    # Special case: BHS numbering has no Malachi 4 (it is Mal 3:19-24), so
    # the article carries no bible+bhs milestone for it. Anchor at the
    # paragraph quoting Mal 4:1 ("For behold the day cometh").
    mal_vol = book_vol["MAL"]
    p = stream.find("For behold the day cometh", int(mal_vol["start"]),
                    int(mal_vol["end"]))
    if p != -1:
        anchors["MAL"][4] = stream.rfind("\n\n", 0, p)
    else:
        print("  WARN MAL ch4: fallback anchor missing")

    spans = {}
    for v in vols:
        for bi, osis in enumerate(v["books"]):
            if bi == 0:
                tstart = v["start"]
            else:
                a1 = anchors[osis].get(1)
                tstart = para_break_before(a1) if a1 is not None else None
            spans[osis] = {"start": tstart}
    for v in vols:
        for bi, osis in enumerate(v["books"]):
            if bi + 1 < len(v["books"]):
                spans[osis]["end"] = spans[v["books"][bi + 1]]["start"]
            else:
                spans[osis]["end"] = v["end"]

    outdir = WS / "kd-json"
    outdir.mkdir(exist_ok=True)
    manifest = {}
    for osis, bnum, name, nchap in BOOKS:
        sp, got = spans[osis], anchors[osis]
        chapters, clist = {}, sorted(got)
        cuts = []
        for ci, c in enumerate(clist):
            cstart = sp["start"] if c == 1 else para_break_before(got[c])
            cend = (sp["end"] if ci + 1 == len(clist)
                    else para_break_before(got[clist[ci + 1]]))
            cuts.append([cstart, cend])
        # repair empty chapters: consecutive anchors can share one paragraph;
        # give the joint paragraph to the earlier chapter and push the
        # later chapter's start past it.
        for ci in range(len(clist) - 1):
            if cuts[ci][1] <= cuts[ci][0]:
                q = stream.find("\n\n", int(got[clist[ci]]))
                if q == -1:
                    q = cuts[ci][1]
                cuts[ci][1] = q
                cuts[ci][0] = min(cuts[ci][0], q)
        for ci in range(1, len(clist)):
            cuts[ci][0] = max(cuts[ci][0], cuts[ci - 1][1])
        for ci, c in enumerate(clist):
            chapters[str(c)] = stream[int(cuts[ci][0]):int(cuts[ci][1])].strip()

        # K&D often treats chapters jointly: a short "Ch. X and Y" /
        # "Ch. X–Z" heading paragraph with the exposition filed under the
        # last chapter of the group. Fill empty/heading-only chapters in a
        # group with heading + exposition so every chapter is readable.
        grp_re = re.compile(r"Chs?\.\s*(\d+)\s*(?:and|–|-|&|to)\s*(\d+)")
        for ci, c in enumerate(clist):
            body = chapters[str(c)]
            if len(body) >= 260:
                continue
            m = grp_re.search(body)
            if not m:
                continue
            c2 = int(m.group(2))
            if c2 <= c or str(c2) not in chapters:
                continue
            tail = chapters[str(c2)]
            if not tail or tail == body:
                continue
            group_text = (body + "\n\n" + tail).strip()
            for cc in range(c, c2 + 1):
                cur = chapters.get(str(cc), "")
                if len(cur) < 260:
                    chapters[str(cc)] = group_text
        # any chapter still empty: inherit the next chapter's text
        for ci, c in enumerate(clist[:-1]):
            if len(chapters[str(c)]) < 50:
                nxt = chapters[str(clist[ci + 1])]
                if nxt:
                    chapters[str(c)] = nxt
        if len(chapters) != nchap:
            print(f"  WARN {osis}: {len(chapters)}/{nchap} chapters")
        doc = {"book": osis, "name": name, "attribution": ATTRIB,
               "intro": None, "chapters": chapters}
        with open(outdir / f"{osis}.json", "w", encoding="utf-8") as fh:
            json.dump(doc, fh, ensure_ascii=False, indent=1)
        total = sum(len(c) for c in chapters.values())
        c1 = chapters.get("1", "")[:70].replace("\n\n", " ¶ ")
        print(f"  {osis}: {len(chapters)} ch, {total} chars | {c1}")
        manifest[osis] = {"name": name, "file": f"{osis}.json",
                          "chapters": len(chapters), "textChars": total}
    with open(outdir / "manifest.json", "w", encoding="utf-8") as fh:
        json.dump(dict(sorted(manifest.items())), fh, ensure_ascii=False,
                  indent=1)
    print(f"\nmanifest: {len(manifest)} books, "
          f"{sum(v['textChars'] for v in manifest.values())} chars")


if __name__ == "__main__":
    main()
