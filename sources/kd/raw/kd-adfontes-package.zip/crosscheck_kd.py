#!/usr/bin/env python3
"""Cross-check the Logos-derived K&D dataset against SermonIndex's
independent transcription, chapter by chapter (token multiset coverage).
Usage: crosscheck_kd.py [<OSIS> <CH>] ... (default: built-in sample)."""
import html as H
import json
import re
import sys
import time
import unicodedata
import urllib.request
from collections import Counter
from pathlib import Path

WS = Path("/Users/lherzog/Documents/kimi/tasks/2026-10-08/11-17-29-e2ed6567")

# SermonIndex URL codes (SWORD abbreviations)
SI = {"GEN": "GEN", "EXO": "EXO", "LEV": "LEV", "NUM": "NUM", "DEU": "DEU",
      "JOS": "JOS", "JDG": "JDG", "RUT": "RUT", "1SA": "1SA", "2SA": "2SA",
      "1KI": "1KI", "2KI": "2KI", "1CH": "1CH", "2CH": "2CH", "EZR": "EZR",
      "NEH": "NEH", "EST": "EST", "JOB": "JOB", "PSA": "PSA", "PRO": "PRO",
      "ECC": "ECC", "SNG": "SOS", "ISA": "ISA", "JER": "JER", "LAM": "LAM",
      "EZK": "EZK", "DAN": "DAN", "HOS": "HOS", "JOL": "JOL", "AMO": "AMO",
      "OBA": "OBA", "JON": "JON", "MIC": "MIC", "NAM": "NAH", "HAB": "HAB",
      "ZEP": "ZEP", "HAG": "HAG", "ZEC": "ZEC", "MAL": "MAL"}

SAMPLE = [("GEN", 1), ("GEN", 45), ("EXO", 11), ("EXO", 20), ("LEV", 4),
          ("NUM", 13), ("DEU", 2), ("JOS", 3), ("JDG", 4), ("RUT", 1),
          ("1SA", 17), ("2SA", 7), ("1KI", 3), ("2KI", 5), ("1CH", 18),
          ("2CH", 11), ("EZR", 3), ("NEH", 3), ("EST", 2), ("JOB", 1),
          ("PSA", 23), ("PSA", 110), ("PRO", 8), ("ECC", 3), ("SNG", 2),
          ("ISA", 6), ("ISA", 53), ("JER", 7), ("LAM", 3), ("EZK", 1),
          ("DAN", 7), ("HOS", 4), ("JOL", 2), ("AMO", 5), ("OBA", 1),
          ("JON", 2), ("MIC", 6), ("NAM", 1), ("HAB", 3), ("ZEP", 2),
          ("HAG", 2), ("ZEC", 4), ("MAL", 4)]


def toks(text):
    text = unicodedata.normalize("NFKD", text)
    text = "".join(c for c in text if not unicodedata.combining(c))
    out = []
    for para in re.split(r"\n+|</p>|</div>|</h\d>", text):
        para = re.sub(r"^\s*(?:Verse\s+)?\d{1,3}[\)\.:]?\s*", "", para.strip())
        para = re.sub(r"[^0-9a-z]+", " ", para.lower())
        out.extend(para.split())
    return out


def fetch_si(osis, ch):
    url = f"https://www.sermonindex.net/commentary/keil-delitzsch/{SI[osis]}/{ch}"
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                      "AppleWebKit/537.36 Chrome/120.0 Safari/537.36"})
    with urllib.request.urlopen(req, timeout=30) as r:
        h = r.read().decode("utf-8", "replace")
    i = h.find('class="bch-content comm-content"')
    if i == -1:
        return ""
    j = h.find("</main>", i)
    body = h[i:j if j != -1 else len(h)]
    body = re.sub(r"<script.*?</script>|<style.*?</style>", " ", body,
                  flags=re.S)
    body = H.unescape(re.sub(r"<[^>]+>", " ", body))
    return re.sub(r"\s+", " ", body)


def main():
    pairs = SAMPLE
    if len(sys.argv) > 2:
        pairs = [(sys.argv[i], int(sys.argv[i + 1]))
                 for i in range(1, len(sys.argv) - 1, 2)]
    agg_l = agg_cov = 0
    for osis, ch in pairs:
        doc = json.load(open(WS / "kd-json" / f"{osis}.json", encoding="utf-8"))
        tl = toks(doc["chapters"][str(ch)])
        try:
            si = fetch_si(osis, ch)
        except Exception as e:
            print(f"{osis} {ch}: FETCH ERR {e}")
            continue
        ts = toks(si)
        cov = sum((Counter(tl) & Counter(ts)).values()) / max(len(tl), 1)
        agg_l += len(tl)
        agg_cov += sum((Counter(tl) & Counter(ts)).values())
        flag = "  <-- LOW" if cov < 0.85 and len(tl) > 200 else ""
        print(f"{osis} {ch}: {cov*100:5.1f}%  (L={len(tl)} SI={len(ts)}){flag}")
        time.sleep(0.4)
    print(f"\nAGGREGATE: {100*agg_cov/max(agg_l,1):.2f}% of Logos tokens "
          f"present in SermonIndex")


if __name__ == "__main__":
    main()
