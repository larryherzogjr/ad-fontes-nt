#!/usr/bin/env python3
"""Recursively expand the K&D TOC tree via WebBridge. Saves every TOC entry
(with level and parent) to kd-toc-tree.jsonl. Resumable via kd-toc-queue.json."""
import json
import os
import urllib.request

WS = "/Users/lherzog/Documents/kimi/tasks/2026-10-08/11-17-29-e2ed6567"
OUT = f"{WS}/kd-toc-tree.jsonl"
QUEUE = f"{WS}/kd-toc-queue.json"

JS = """(async()=>{
const id=encodeURIComponent('LLS:29.2.11');
const q=%s, done=[];
for(const item of q){
  const r=await fetch('/api/app/books/'+id+'/tableofcontents?parentId='+encodeURIComponent(item.id),{credentials:'include'});
  const kids=await r.json();
  done.push({parent:item, kids});
}
return JSON.stringify(done);
})()"""


def call(js):
    body = json.dumps({"action": "evaluate", "args": {"code": js},
                       "session": "lenski-logos"}).encode()
    req = urllib.request.Request("http://127.0.0.1:10086/command",
                                 data=body, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        d = json.load(r)
    if not d.get("ok"):
        raise RuntimeError(d)
    return d["data"]["value"]


def main():
    if os.path.exists(QUEUE):
        queue = json.load(open(QUEUE))
        mode = "a"
    else:
        queue = [{"id": "ROOT", "level": 0, "title": None, "parent": None}]
        mode = "w"
    seen = set()
    if os.path.exists(OUT) and mode == "a":
        with open(OUT, encoding="utf-8") as fh:
            for line in fh:
                seen.add(json.loads(line)["id"])
    total_new = 0
    with open(OUT, mode, encoding="utf-8") as fh:
        while queue:
            batch, rest = queue[:20], queue[20:]
            # ROOT: fetch top-level TOC (no parentId)
            roots = [b for b in batch if b["id"] == "ROOT"]
            real = [b for b in batch if b["id"] != "ROOT"]
            results = []
            if real:
                results += json.loads(call(JS % json.dumps(real)))
            if roots:
                js = """(async()=>{const id=encodeURIComponent('LLS:29.2.11');
                    const r=await fetch('/api/app/books/'+id+'/tableofcontents',{credentials:'include'});
                    return JSON.stringify([{parent:{id:'ROOT',level:0,title:null,parent:null},kids:await r.json()}]);})()"""
                results += json.loads(call(js))
            for res in results:
                par = res["parent"]
                for k in res["kids"]:
                    entry = {"id": k["id"], "title": k["title"],
                             "off": k["indexedOffset"], "len": k["indexedLength"],
                             "hasCh": k["hasChildren"], "level": par["level"] + 1,
                             "parent": par["title"]}
                    if entry["id"] in seen:
                        continue
                    seen.add(entry["id"])
                    fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
                    total_new += 1
                    if k["hasChildren"]:
                        rest.append({"id": k["id"], "level": par["level"] + 1,
                                     "title": k["title"], "parent": par["title"]})
            fh.flush()
            queue = rest
            json.dump(queue, open(QUEUE, "w"))
            print(f"new entries: {total_new}, queue: {len(queue)}")
    os.remove(QUEUE)
    print("done")


if __name__ == "__main__":
    main()
