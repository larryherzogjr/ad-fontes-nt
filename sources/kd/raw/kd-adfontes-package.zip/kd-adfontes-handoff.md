# Handoff: Incorporate Keil & Delitzsch's OT Commentary into Ad Fontes

**For:** Codex (agent maintaining ad-fontes.app)
**From:** Research + data-prep session, 2026-10-08
**Owner:** Larry Herzog Jr. (Ordinary Means)

---

## 1. Objective

Add C. F. Keil and F. Delitzsch's *Commentary on the Old Testament* to
ad-fontes.app as (a) a commentary pane in the reader (routes like
`/read/GEN/1`) and (b) a "Commentaries" collection in the Study Library,
alongside the already-delivered Lenski NT set.

---

## 2. Copyright status — researched, with evidence

Do not re-derive. This is **simpler than the Lenski case: there are no
serving constraints anywhere.**

- **Public domain worldwide.** Keil died 1888, Delitzsch died 1890; the
  work was published 1864–1891 (T. & T. Clark, Edinburgh; Hendrickson
  reprint 1980 is a straight reprint of the PD text and adds no new
  copyright in the text itself). Life+70 in the EU expired by 1961 at the
  latest; in the U.S. everything pre-1931 is PD regardless of renewal.
- **No EU-vs-US split, no geo-serving rules.** Unlike Lenski, the full
  text may be served to any visitor from any edge. Static hosting and CDN
  full-body caching are both fine.
- Show this attribution in the resource's About panel (it is already in
  every JSON file's `attribution` field):
  > C. F. Keil and F. Delitzsch, *Commentary on the Old Testament*
  > (Edinburgh: T. & T. Clark, 1864–1891). Public domain.

**Provenance:** the delivered text was extracted from the owner's own
Logos subscription (publisher edition, resource `LLS:29.2.11`) at the
owner's explicit direction; do not substitute text from other
transcriptions without re-running the QA in §5.

---

## 3. Delivered data — `kd-json/` (all 39 books, single source)

**Source: the owner's Logos web app** (app.logos.com, single resource
`LLS:29.2.11`, "Commentary on the Old Testament", version
2019-08-01T22:56:47Z, resource length 25,807,633 chars). All 39 books
come from this one resource, so formatting is uniform across the set.

Extraction pipeline (all scripts included in this package):

1. `extract_kd_articles.py` — walks the resource's article chain
   (TITLE → PUBPREF → BK.\* → DIV565-722 [the Psalms subdivisions] →
   MAL1.4) via Logos's `/api/app/books/{id}/articles/{articleId}`
   endpoint (each article's HTML carries the `nextArticleId` pointer).
   Pulled 1,205 articles contiguously; article offsets exactly tile the
   resource with no gaps or overlaps. Resumable (JSONL append).
2. `extract_kd_toc.py` — recursive walk of
   `/api/app/books/{id}/tableofcontents?parentId={id}` producing the full
   TOC tree (1,203 entries) with `indexedOffsets` used for anchor
   interpolation in step 3.
3. `build_kd.py` — the assembler; converts each article's HTML to plain
   text, locates chapter anchors from `<a rel="milestone">` elements
   carrying machine refs (`bible+bhs.*`, formats B.C.V, B.C, B.C.V–B.C.V,
   B.C–B.C, optional `++` suffix), maps TOC `indexedOffsets` into text
   coordinates by interpolating between `<span class="offset-marker">`
   markers, and cuts chapters at the preceding blank line (`\n\n`).
   Cut priority per chapter: first anchor exactly at B.C.1, else first
   anchor starting in chapter C, else anchor spanning into C.
4. `crosscheck_kd.py` — per-chapter token-multiset coverage against
   SermonIndex's independent transcription of the same work (QA in §5).

Requires the owner's logged-in Chrome session via WebBridge
(`POST http://127.0.0.1:10086/command`, action `evaluate`, session
`lenski-logos`) for steps 1–2 only; step 3+ runs offline from the
JSONL dumps.

**Why not theWord / SWORD / StudyLight / BibleHub transcriptions:**
SermonIndex hosts a SWORD module and StudyLight/BibleHub carry the same
text, but they are independent transcriptions with their own
segmentation choices (see QA deltas). The Logos publisher edition was
chosen for consistency with the Lenski pipeline — same source system,
same edition quality, uniform formatting across the whole set. Note:
Logos's `canvas/wordshapedata` renderer API used for Lenski does **not**
work on this resource; the article-HTML API above was used instead.

### JSON schema (exactly as delivered)

One file per book: `kd-json/<OSIS>.json` (e.g. `GEN.json`).

```json
{
 "book": "GEN",
 "name": "Genesis",
 "attribution": "C. F. Keil and F. Delitzsch, Commentary on the Old Testament (Edinburgh: T. & T. Clark, 1864–1891). Public domain.",
 "intro": null,
 "chapters": {
  "1": "The First Book of Moses (Genesis) \n\nTranslated by \n\nJames Martin \n\nGENERAL INTRODUCTION TO THE FIVE BOOKS OF MOSES \n\n§1. Prolegomena on …",
  "2": "…"
 }
}
```

- `book` — OSIS book id, all 39 OT books: GEN, EXO, LEV, NUM, DEU, JOS,
  JDG, RUT, 1SA, 2SA, 1KI, 2KI, 1CH, 2CH, EZR, NEH, EST, JOB, PSA, PRO,
  ECC, SNG, ISA, JER, LAM, EZK, DAN, HOS, JOL, AMO, OBA, JON, MIC, NAM,
  HAB, ZEP, HAG, ZEC, MAL.
- `name` — English book name.
- `attribution` — as above, identical in every file.
- `intro` — always `null` in this dataset. Introductory material lives
  inside chapter 1 of the book it belongs to (see conventions below).
- `chapters` — object keyed by **1-based chapter number as a string**.
  Value: the full chapter commentary as plain text.
- **Paragraphs are separated by `\n\n`** (blank line). Files are written
  with `indent=1`, `ensure_ascii=False`.

`kd-json/manifest.json` is an object keyed by OSIS id; each value is
`{"name", "file", "chapters", "textChars"}` (English name, JSON file
name, chapter count, total commentary character count for that book). Totals: **39 books, 929 chapters (every OT
chapter), 26,553,864 chars**; smallest chapter is LEV 4 at 952 chars
(short chapters got content via the joint-chapter convention below).

### Formatting conventions Codex must know

These are uniform across all 39 files and differ from the Lenski set — do
not assume the Lenski conventions:

1. **Verse comments are headed by a bold-style lemma rendered as plain
   text.** Within a chapter, each verse or verse-range comment begins
   with a paragraph starting like `Verse 1.` or `Ch. 2:5–25.` or
   `vv. 3-5.` (spellings vary by volume: `Verse`, `Vers.`, `vv.`, `Ch.`,
   arabic or Roman numerals). There is no machine verse-level markup —
   split on paragraphs matching `^(Verse|Vers\.|vv\.|Ch\.)\s` at display
   time if verse granularity is wanted. Section headings are also plain
   paragraphs (centered in the original typesetting, now unmarked), e.g.
   `GENERAL INTRODUCTION TO THE FIVE BOOKS OF MOSES`, `§1. Prolegomena
   on the Old Testament and Its Leading Divisions`, or
   `Oppression of Israel by Jabin, and Deliverance by Deborah and
   Barak.—Ch. 4 and 5`.
2. **Joint-chapter groups are duplicated under each covered chapter.**
   Where Keil & Delitzsch treat consecutive chapters as one unit (heading
   like `Ch. 4 and 5` or `Chs. X–Z`), the assembled text is stored under
   *every* chapter in the range, so a reader opening any covered chapter
   sees the full commentary. This means group text appears in multiple
   JSON files' chapters (e.g. JDG 4 and JDG 5 share their exposition);
   the per-file manifest counts include this duplication. Chapters that
   had no exposition of their own inherit the covering group's text.
3. **Book/volume introductions live in chapter 1** of the book that
   follows them, per this map:
   - Title + Publisher's Preface + (Keil's) Preface → GEN 1
   - Prophetical Histories general introduction → JOS 1
   - Prophetical Books general introduction → ISA 1
   - Twelve Minor Prophets general introduction → HOS 1
   - Every other book's own introduction → its chapter 1
   So chapter 1 files are substantially larger than mid-book chapters
   (GEN 1 ≈ 130 K chars). Do not treat this as an error.
4. **Multi-book volumes are split at the second book's 1:1 anchor**
   (1SA/2SA, 1KI/2KI, 1CH/2CH). The first book's file contains only its
   own chapters.
5. **Malachi 4:** the BHS milestone scheme has no Mal 4 (Christian
   chaptering; BHS treats Mal 3:19–24 as 3:19–24). MAL.json chapter "4"
   was anchored by a special case at the paragraph containing
   "For behold the day cometh" and contains Mal 3:19–24 exposition.
6. **Hebrew and Greek are inline Unicode** (unpointed Hebrew with
   occasional pointing, polytonic Greek for LXX quotes), from the
   publisher's typesetting — no OCR artifacts, no HTML entities, no
   markup residue (verified by scan: zero `<`, `&`, null bytes, or
   offset-marker leakage across all 26.5 M chars).

### Regenerating / extending

- `extract_kd_articles.py` → `kd-articles.jsonl` (1,205 articles; needs
  the owner's logged-in Chrome session).
- `extract_kd_toc.py` → `kd-toc-tree.jsonl` (1,203 TOC entries).
- `build_kd.py` → `kd-json/*.json` + `manifest.json` (offline; reruns
  deterministically from the two JSONL dumps, which are *not* in this
  package — regenerate via the two extractors if needed).
- `crosscheck_kd.py` → QA report vs SermonIndex (network).

---

## 4. Integration notes

1. **Reader commentary pane:** for the passage in view, fetch the book
   JSON, take `chapters[<chapter number as string>]`, optionally split
   into verse-range paragraphs per convention 1, and show entries
   overlapping the current verse. Lazy-load per book (some chapter-1
   payloads are ~130 K chars).
2. **Library collection:** "Commentaries → Keil & Delitzsch on the Old
   Testament", per-book browsing, full-text search (the JSON is plain
   text; index with the repo's existing search approach).
3. **Attribution** from §2 in the About panel.
4. Consider surfacing the joint-chapter heading (convention 2) as a
   "covers chapters X–Y" badge so a reader isn't confused why JDG 4 and
   5 share text.

## 5. QA status

- [x] All 39 OT books present; all 929 chapters present; no chapter
      under 952 chars.
- [x] Article chain tiles the resource exactly (1,205 articles, offsets
      contiguous, no gaps/overlaps).
- [x] No HTML/entity/offset-marker residue in output (26.5 M-char scan).
- [x] Hebrew/Greek inline Unicode intact.
- [x] **Cross-validated against SermonIndex's independent transcription**
      (`crosscheck_kd.py`, 42-chapter sample, token-multiset per
      chapter): typical chapters 92–100% of Logos tokens present in the
      SermonIndex text; aggregate ~80%. Manual inspection of every low
      outlier (EZK 1, OBA 1, GEN 1, JDG 4, MIC 6, NAM 1, MAL 4) found
      the deltas are all SermonIndex-side: their segmentation omits or
      shortens (a) book/volume introductions that our chapter 1 files
      legitimately include, (b) one member of each joint-chapter group
      (we duplicate, they don't), and (c) some scripture-translation
      quotations they render differently. No genuine K&D prose was
      found missing on our side.
- [x] Malachi 4 special case verified (contains Mal 3:19–24 exposition).
- [ ] Attribution visible in UI.
- [ ] Post-deploy spot check of a few chapters in the reader.

## 6. Out of scope

Other commentaries, NT works (Lenski handoff covers those), paywalling,
verse-level splitting at the data layer (kept as a display-time concern).
