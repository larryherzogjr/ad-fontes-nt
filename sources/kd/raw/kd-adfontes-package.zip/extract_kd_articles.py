#!/usr/bin/env python3
"""Walk the K&D (LLS:29.2.11) article chain via WebBridge and save every
article's HTML to kd-articles.jsonl. Idempotent: resumes from the last
article id in the output file."""
import json
import sys
import time
import urllib.request

WS = "/Users/lherzog/Documents/kimi/tasks/2026-10-08/11-17-29-e2ed6567"
OUT = f"{WS}/kd-articles.jsonl"
BATCH = 25

JS = """(async()=>{
const id=encodeURIComponent('LLS:29.2.11');
let aid=%s, out=[];
for(let i=0;i<%d&&aid;i++){
  const r=await fetch('/api/app/books/'+id+'/articles/'+encodeURIComponent(aid),{credentials:'include'});
  if(!r.ok){out.push({id:aid,error:r.status});break;}
  const j=await r.json();
  out.push({id:aid,off:j.article.indexedOffset,len:j.article.indexedLength,
            next:j.nextArticleId,html:j.article.content});
  aid=j.nextArticleId;
}
return JSON.stringify({rows:out,next:aid});
})()"""


def call(js):
    body = json.dumps({"action": "evaluate", "args": {"code": js},
                       "session": "lenski-logos"}).encode()
    req = urllib.request.Request("http://127.0.0.1:10086/command",
                                 data=body, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=120) as r:
        d = json.load(r)
    if not d.get("ok"):
        raise RuntimeError(d)
    return d["data"]["value"]


def last_cursor():
    try:
        with open(OUT, encoding="utf-8") as fh:
            last = None
            for line in fh:
                last = line
        return json.loads(last)["id"] if last else "TITLE"
    except FileNotFoundError:
        return "TITLE"


def main():
    cur = last_cursor()
    n = 0
    with open(OUT, "a", encoding="utf-8") as fh:
        while True:
            v = json.loads(call(JS % (json.dumps(cur), BATCH)))
            rows = v["rows"]
            if not rows:
                print("no rows; done")
                break
            for row in rows:
                fh.write(json.dumps(row, ensure_ascii=False) + "\n")
                n += 1
                if "error" in row:
                    print("ERROR at", row["id"], row["error"])
                    return
                cur = row["id"]
            fh.flush()
            print(f"{n} articles, at {cur} off={rows[-1]['off']+rows[-1]['len']}")
            if not v["next"]:
                print("chain end; done")
                break
            cur = v["next"]
            time.sleep(0.3)


if __name__ == "__main__":
    main()
