#!/usr/bin/env python3
"""Per-chapter multiset coverage of the new Logos-sourced dataset
(lenski-json-sword/) against the previous SWORD-derived reference
(lenski-json-previous/). Normalizes both sides identically; reports
L-coverage (share of Logos chapter tokens present in SWORD) per chapter.
Low L-coverage with L >> S tokens = bleed/cut defect in the new build;
high L-coverage well under 100% with S-side gaps = SWORD truncation
(Logos text is the publisher edition and wins)."""
import json
import re
import unicodedata
from collections import Counter
from pathlib import Path

WS = Path("/Users/lherzog/Documents/kimi/tasks/2026-10-08/11-17-29-e2ed6567")
NEW = WS / "lenski-json-sword"
OLD = WS / "lenski-json-previous"

VERSE = re.compile(r"^\d{1,3}[\)\.]?\s+")


def toks(text):
    text = unicodedata.normalize("NFKD", text)
    text = "".join(c for c in text if not unicodedata.combining(c))
    out = []
    for para in text.split("\n\n"):
        para = VERSE.sub("", para.strip())
        para = re.sub(r"[^0-9a-z]+", " ", para.lower())
        out.extend(para.split())
    return out


def main():
    flag = []
    for f in sorted(NEW.glob("*.json")):
        if f.name == "manifest.json":
            continue
        new = json.load(open(f, encoding="utf-8"))
        old_f = OLD / f.name
        if not old_f.exists():
            print(f"{f.stem}: no reference")
            continue
        old = json.load(open(old_f, encoding="utf-8"))
        for ch in sorted(new["chapters"], key=int):
            tn = toks(new["chapters"][ch])
            to = toks(old["chapters"].get(ch, ""))
            if not tn:
                print(f"{f.stem} ch{ch}: EMPTY")
                flag.append((f.stem, ch, 0.0, 0, 0))
                continue
            cov = sum((Counter(tn) & Counter(to)).values()) / len(tn)
            if cov < 0.97:
                flag.append((f.stem, ch, cov, len(tn), len(to)))
    print("\n--- chapters below 97% L-coverage ---")
    for stem, ch, cov, ln, lo in flag:
        print(f"{stem} ch{ch}: {cov*100:5.1f}%  L={ln} S={lo}")


if __name__ == "__main__":
    main()
