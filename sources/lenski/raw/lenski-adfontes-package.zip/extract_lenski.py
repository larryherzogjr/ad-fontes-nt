#!/usr/bin/env python3
"""Extract Lenski NT commentary text from a theWord .cmt.twm module.

The module is a SQLite DB; each entry's content is a zlib-compressed
TRichView RVF stream. This parser walks the item stream and extracts
text runs, skipping pictures, and joins them into plain text with
paragraph breaks at RVF break/horizontal-rule items and before verse-
number runs (Lenski numbers each verse comment "N.").
"""
import sqlite3, zlib, re, json, os, sys, html

DB = 'Lenski-NTCommentary.cmt.twm'
OUT = 'lenski-json'

BOOKS = {  # theWord book index -> (OSIS id, name)
    40: ('MAT', 'Matthew'), 41: ('MRK', 'Mark'), 42: ('LUK', 'Luke'),
    43: ('JHN', 'John'), 44: ('ACT', 'Acts'), 45: ('ROM', 'Romans'),
    46: ('1CO', '1 Corinthians'), 47: ('2CO', '2 Corinthians'),
    48: ('GAL', 'Galatians'), 49: ('EPH', 'Ephesians'), 50: ('PHP', 'Philippians'),
    51: ('COL', 'Colossians'), 52: ('1TH', '1 Thessalonians'), 53: ('2TH', '2 Thessalonians'),
    54: ('1TI', '1 Timothy'), 55: ('2TI', '2 Timothy'), 56: ('TIT', 'Titus'),
    57: ('PHM', 'Philemon'), 58: ('HEB', 'Hebrews'), 59: ('JAS', 'James'),
    60: ('1PE', '1 Peter'), 61: ('2PE', '2 Peter'), 62: ('1JN', '1 John'),
    63: ('2JN', '2 John'), 64: ('3JN', '3 John'), 65: ('JUD', 'Jude'),
    66: ('REV', 'Revelation'),
}

HDR_RE = re.compile(rb'^(-?\d+)(\s+-?\d+){0,6}\r\n$')
TEXT_TYPES = {0, 1, 6, 7, 8, 9, 15}
unknown_types = {}
problems = []

def read_header(buf, pos):
    """Try to read an item header line at pos. Returns (tokens, newpos) or None."""
    end = buf.find(b'\r\n', pos, pos + 64)
    if end < 0:
        return None
    line = buf[pos:end + 2]
    m = HDR_RE.match(line)
    if not m:
        return None
    try:
        toks = [int(x) for x in line[:-2].split()]
    except ValueError:
        return None
    # reject implausible headers (huge ints)
    if any(abs(t) > 10**9 for t in toks):
        return None
    return toks, end + 2

def read_run(buf, pos):
    """Read a UTF-16LE text run terminated by byte 0x14. Returns (text, newpos)."""
    end = buf.find(b'\x14', pos)
    if end < 0:
        return None, len(buf)
    raw = buf[pos:end]
    if len(raw) % 2 == 0 and len(raw) >= 2:
        try:
            s = raw.decode('utf-16-le')
        except UnicodeDecodeError:
            s = raw.decode('latin-1', errors='replace')
    else:
        s = raw.decode('latin-1', errors='replace')
    return s, end + 1

def skip_picture(buf, pos):
    """Skip TBitmap image sub-stream(s) after a picture item header."""
    skipped = 0
    while buf.startswith(b'TBitmap\r\n', pos):
        pos += len(b'TBitmap\r\n')
        if pos + 4 > len(buf):
            break
        size = int.from_bytes(buf[pos:pos + 4], 'little')
        pos += 4 + size
        if buf[pos:pos + 2] == b'\r\n':
            pos += 2
        skipped += 1
        if size <= 0 or size > 50_000_000:
            break
    return pos, skipped

def parse_entry(buf):
    """Parse one RVF stream -> plain text (paragraphs joined by \n\n)."""
    # content starts after the '-9 0 0 0 0 0 N' marker line
    m = re.search(rb'-9 0 0 0 0 0 -?\d+\r\n', buf)
    if not m:
        return None, 'no content marker'
    pos = m.end()
    runs = []          # list of (style_guess, text)
    breaks = set()     # indices in runs where a paragraph break follows
    idx = 0
    pics = 0
    while pos < len(buf):
        hdr = read_header(buf, pos)
        if hdr:
            toks, pos = hdr
            t = toks[0]
            if t in TEXT_TYPES:
                s, pos = read_run(buf, pos)
                if s is None:
                    break
                runs.append(s)
                idx += 1
            elif t == -3:
                pos, n = skip_picture(buf, pos)
                pics += n
            elif t == 10:      # break
                breaks.add(idx)
            elif t == 11:      # horizontal line
                breaks.add(idx)
            elif t in (-8, -9, -2, 2, 4, 5, 12, 13, 3, 14, 16, 17, 18):
                # style/table/footnote markers: no inline text to take
                if t not in (-8, -9):
                    unknown_types[t] = unknown_types.get(t, 0) + 1
            else:
                unknown_types[t] = unknown_types.get(t, 0) + 1
                # try to skip a run if one follows
                s, pos2 = read_run(buf, pos)
                if s is not None and len(s) < 400:
                    pos = pos2
        else:
            # not a header: either a stray run (like "By") or the end
            s, pos2 = read_run(buf, pos)
            if s is None:
                break
            if s.strip():
                runs.append(s)
                idx += 1
            pos = pos2
    if not runs:
        return '', None
    # assemble paragraphs
    out = []
    for i, s in enumerate(runs):
        s = s.replace('\r', ' ').strip('\x00').strip()
        if not s:
            continue
        if not out or (i in breaks):
            out.append(s)
        else:
            # verse-number run at item start -> new paragraph
            if re.match(r'^\d{1,3}[.:]\s', s) and len(s) > 3:
                out.append(s)
            else:
                out[-1] += ' ' + s
    text = '\n\n'.join(p for p in out if p.strip())
    # verse markers: ensure "N. " at paragraph starts survived
    return text, None if pics == 0 else f'{pics} pictures skipped'

def main():
    con = sqlite3.connect(DB)
    cur = con.cursor()
    os.makedirs(OUT, exist_ok=True)
    manifest = {}
    for bi, (osis, name) in BOOKS.items():
        rows = cur.execute(
            "SELECT b.ci, b.fvi, b.tvi, c.data FROM bible_refs b "
            "JOIN content c ON c.topic_id=b.topic_id WHERE b.bi=? ORDER BY b.ci, b.fvi",
            (bi,)).fetchall()
        intro, chapters = None, {}
        n_stubs = 0
        for ci, fvi, tvi, blob in rows:
            if not blob:
                continue
            try:
                dec = zlib.decompress(blob)
            except Exception:
                problems.append(f'{osis} {ci}:{fvi} zlib fail')
                continue
            if len(dec) < 300:
                n_stubs += 1
                continue
            text, note = parse_entry(dec)
            if text is None:
                problems.append(f'{osis} {ci}:{fvi} parse: {note}')
                continue
            if note:
                problems.append(f'{osis} {ci}:{fvi} {note}')
            if ci == 0 and fvi == 0:
                intro = text
            else:
                chapters[str(ci)] = text
        doc = {
            'book': osis,
            'name': name,
            'attribution': ('R. C. H. Lenski, The Interpretation of '
                            'the New Testament (Wartburg Press / Augsburg, '
                            '1932–1946). Public domain in the EU.'),
            'intro': intro,
            'chapters': chapters,
        }
        path = os.path.join(OUT, f'{osis}.json')
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(doc, f, ensure_ascii=False, indent=1)
        manifest[osis] = {
            'name': name,
            'file': f'{osis}.json',
            'chapters': len(chapters),
            'introChars': len(intro or ''),
            'textChars': sum(len(t) for t in chapters.values()),
        }
        print(f'{osis:4s} {name:18s} chapters={len(chapters):3d} '
              f'chars={sum(len(t) for t in chapters.values()):8d} stubs={n_stubs}')
    with open(os.path.join(OUT, 'manifest.json'), 'w', encoding='utf-8') as f:
        json.dump(manifest, f, ensure_ascii=False, indent=1)
    print('\nunknown item types seen:', unknown_types)
    print('problems:', len(problems))
    for p in problems[:25]:
        print('  -', p)

if __name__ == '__main__':
    main()
