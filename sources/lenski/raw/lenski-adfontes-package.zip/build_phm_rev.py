#!/usr/bin/env python3
"""Assemble PHM.json / REV.json from raw-logos JSONL segments.

- Joins batch segments in page order (separator from paragraphStart flag).
- Splits paragraphs globally via the paragraphStart offset list (poffs).
- REV: splits into chapters at the LENSKI12 TOC offsets; the volume
  Introduction section is prepended to chapter 1 (dataset convention:
  front matter lives inside chapter 1; intro field stays null).
- PHM: single-chapter book (whole Philemon article).
- Heuristic: paragraphs starting with a lowercase ASCII letter are merged
  into the previous paragraph (guards against spurious page-break
  paragraphStart flags).
"""
import html
import json
import re
import sys

WS = "/Users/lherzog/Documents/kimi/tasks/2026-10-08/11-17-29-e2ed6567"
ATTRIB = ("R. C. H. Lenski, The Interpretation of the New Testament "
          "(Wartburg Press / Augsburg, 1932–1946). Public domain in the EU.")

REV_TOC = {  # LENSKI12 tableofcontents
    "intro": ("Introduction", 3398),
    "1": ("Chapter 1", 40319), "2": ("Chapter 2", 143320),
    "3": ("Chapter 3", 225087), "4": ("Chapter 4", 299317),
    "5": ("Chapter 5", 344482), "6": ("Chapter 6", 386471),
    "7": ("Chapter 7", 441051), "8": ("Chapter 8", 482286),
    "9": ("Chapter 9", 515821), "10": ("Chapter 10", 561390),
    "11": ("Chapter 11", 589704), "12": ("Chapter 12", 655738),
    "13": ("Chapter 13", 704911), "14": ("Chapter 14", 761146),
    "15": ("Chapter 15", 825163), "16": ("Chapter 16", 843470),
    "17": ("Chapter 17", 889153), "18": ("Chapter 18", 936478),
    "19": ("Chapter 19", 971386), "20": ("Chapter 20", 1025130),
    "21": ("Chapter 21", 1116236), "22": ("Chapter 22", 1180529),
}


def load_segments(path):
    segs = []
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            segs.append(json.loads(line))
    # order by first page number (batch ids restart across invocations)
    segs.sort(key=lambda s: int(s["refs"][0].split(".")[1]))
    return segs


def join_segments(segs):
    text = ""
    poffs = []
    prev_last = None
    for s in segs:
        if prev_last is not None and s["first"] is not None and s["first"] <= prev_last:
            print(f"  WARN batch {s['batch']}: offset overlap {s['first']} <= {prev_last}")
        if text:
            text += "\n\n" if s["first"] in set(s["poffs"]) else " "
        text += s["text"]
        poffs.extend(s["poffs"])
        prev_last = s["last"]
    return text, sorted(poffs)


def split_paragraphs(text, poffs):
    paras = text.split("\n\n")
    starts = sorted(poffs)
    if len(paras) != len(starts):
        print(f"  WARN paragraph/token count mismatch: {len(paras)} paras "
              f"vs {len(starts)} poffs")
        # fall back: ignore offsets beyond count
    out = []
    for i, p in enumerate(paras):
        off = starts[i] if i < len(starts) else None
        out.append((off, p.strip()))
    return out


def merge_lowercase(paras):
    """Merge spurious page-break paragraph splits.

    The Logos renderer flags the first word of every rendered page with
    paragraphStart=1, so mid-paragraph page turns surface as fake paragraph
    breaks. A genuine Lenski paragraph never ends on a lowercase letter and
    never ends mid-sentence; headings/title lines (short, ALL-CAPS or both
    sides short) are protected from merging.
    """
    merged, n_merge = [], 0
    for off, p in paras:
        p = p.strip()
        if merged and p:
            prev_text = merged[-1][1]
            cur_head = p[0]
            prev_tail = prev_text[-1] if prev_text else ""
            cur_is_caps = p[:40].isupper()
            both_short = len(prev_text) < 80 and len(p) < 80
            if ((prev_tail.isascii() and prev_tail.islower())
                    or (cur_head.isascii() and cur_head.islower())) \
                    and not cur_is_caps and not both_short:
                merged[-1] = (merged[-1][0], prev_text + " " + p)
                n_merge += 1
                continue
        merged.append((off, p))
    return merged, n_merge


def build(path, name, osis, toc=None):
    print(f"== {osis} ==")
    segs = load_segments(path)
    print(f"  segments: {len(segs)}, words: {sum(s['n'] for s in segs)}")
    text, poffs = join_segments(segs)
    print(f"  joined chars: {len(text)}, paragraph starts: {len(poffs)}")
    paras = split_paragraphs(text, poffs)
    paras, n_merge = merge_lowercase(paras)
    print(f"  paragraphs: {len(paras)} ({n_merge} lowercase merges)")
    amp = sum(p[1].count("&") for p in paras)
    print(f"  '&' occurrences (entities?): {amp}")

    chapters = {}
    if toc:  # REV
        starts = {off: i for i, (off, _) in enumerate(paras) if off is not None}
        keys = [k for k in toc if k != "intro"]
        for idx, k in enumerate(keys):
            off = toc[k][1]
            if off not in starts:
                near = min(starts, key=lambda o: abs(o - off))
                print(f"  WARN chapter {k}: offset {off} not a paragraph start "
                      f"(nearest {near}, delta {off - near})")
                off = near
            end = toc[keys[idx + 1]][1] if idx + 1 < len(keys) else None
            i0 = starts[off]
            i1 = starts.get(end, len(paras)) if end else len(paras)
            body = "\n\n".join(p for _, p in paras[i0:i1] if p)
            if k == "1":
                intro_off = toc["intro"][1]
                intro_i = starts.get(intro_off)
                if intro_i is not None:
                    intro = "\n\n".join(p for _, p in paras[intro_i:i0] if p)
                    body = intro + "\n\n" + body
                else:
                    print("  WARN: intro offset not found; chapter 1 has no intro")
            chapters[k] = body
    else:  # PHM single chapter
        chapters["1"] = "\n\n".join(p for _, p in paras if p)

    doc = {"book": osis, "name": name, "attribution": ATTRIB,
           "intro": None, "chapters": chapters}
    out = f"{WS}/lenski-json-sword/{osis}.json"
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(doc, fh, ensure_ascii=False, indent=1)
    print(f"  wrote {out}: {sum(len(c) for c in chapters.values())} chars, "
          f"{len(chapters)} chapters")
    return {osis: {"name": name, "file": f"{osis}.json",
                   "chapters": len(chapters),
                   "textChars": sum(len(c) for c in chapters.values())}}


if __name__ == "__main__":
    res = {}
    res.update(build(f"{WS}/raw-logos/PHM.jsonl", "Philemon", "PHM"))
    res.update(build(f"{WS}/raw-logos/REV.jsonl", "Revelation", "REV",
                     toc=REV_TOC))
    mpath = f"{WS}/lenski-json-sword/manifest.json"
    with open(mpath, encoding="utf-8") as fh:
        manifest = json.load(fh)
    manifest.update(res)
    manifest = dict(sorted(manifest.items()))
    with open(mpath, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, ensure_ascii=False, indent=1)
    print(f"manifest updated: {len(manifest)} books")
