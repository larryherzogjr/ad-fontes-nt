#!/usr/bin/env python3
"""Assemble the complete 27-book Logos-sourced Lenski dataset from
raw-logos/L01..L12.jsonl page segments + /tmp/lenski_map.json (TOC and
milestone offsets pulled from app.logos.com).

Chapter boundaries: bible chapter milestones (label-matched per book),
supplemented by verse-1 milestones; offsets snap to the nearest paragraph
start (headings are paragraph-initial by construction). Book intros
(everything from the book/article start to chapter 1) live inside chapter 1,
matching the dataset convention.
"""
import json
import re
import sys

WS = "/Users/lherzog/Documents/kimi/tasks/2026-10-08/11-17-29-e2ed6567"
MAP = json.load(open("/tmp/lenski_map.json"))
ATTRIB = ("R. C. H. Lenski, The Interpretation of the New Testament "
          "(Wartburg Press / Augsburg, 1932–1946). Public domain in the EU.")

RESOURCE_BOOKS = {
    "01": [("MAT", "Matthew", 28)],
    "02": [("MRK", "Mark", 16)],
    "03": [("LUK", "Luke", 24)],
    "04": [("JHN", "John", 21)],
    "05": [("ACT", "Acts", 28)],
    "06": [("ROM", "Romans", 16)],
    "07": [("1CO", "1 Corinthians", 16), ("2CO", "2 Corinthians", 13)],
    "08": [("GAL", "Galatians", 6), ("EPH", "Ephesians", 6),
           ("PHP", "Philippians", 4)],
    "09": [("COL", "Colossians", 4), ("1TH", "1 Thessalonians", 5),
           ("2TH", "2 Thessalonians", 3), ("1TI", "1 Timothy", 6),
           ("2TI", "2 Timothy", 4), ("TIT", "Titus", 3), ("PHM", "Philemon", 1)],
    "10": [("HEB", "Hebrews", 13), ("JAS", "James", 5)],
    "11": [("1PE", "1 Peter", 5), ("2PE", "2 Peter", 3), ("1JN", "1 John", 5),
           ("2JN", "2 John", 1), ("3JN", "3 John", 1), ("JUD", "Jude", 1)],
    "12": [("REV", "Revelation", 22)],
}
ARTICLE_HINTS = {  # TOC title fragments identifying each book's article
    "1CO": "First Epistle to the Corinthians",
    "2CO": "Second Epistle to the Corinthians",
    "GAL": "Galatians", "EPH": "Ephesians", "PHP": "Philippians",
    "COL": "Colossians", "1TH": "First Epistle to the Thessalonians",
    "2TH": "Second Epistle to the Thessalonians",
    "1TI": "Timothy", "2TI": "Timothy", "TIT": "Timothy", "PHM": "Philemon",
    "HEB": "Hebrews", "JAS": "James",
    "1PE": "First Epistle of St. Peter", "2PE": "Second Epistle of St. Peter",
    "1JN": "First Epistle of St. John", "2JN": "Second Epistle of St. John",
    "3JN": "Third Epistle of St. John", "JUD": "Jude",
}


def load_segments(path):
    segs = [json.loads(l) for l in open(path, encoding="utf-8")]
    segs.sort(key=lambda s: int(s["refs"][0].split(".")[1]))
    return segs


def join_segments(segs):
    text, poffs = "", []
    prev_last = None
    for s in segs:
        if prev_last is not None and s["first"] <= prev_last:
            print(f"    WARN overlap at batch {s['refs'][0]}")
        if text:
            text += "\n\n" if s["first"] in set(s["poffs"]) else " "
        text += s["text"]
        poffs.extend(s["poffs"])
        prev_last = s["last"]
    return text, sorted(poffs)


def split_paragraphs(text, poffs):
    paras = [p.strip() for p in text.split("\n\n")]
    starts = sorted(poffs)
    if len(paras) != len(starts):
        print(f"    WARN paras {len(paras)} != poffs {len(starts)}")
    return [(starts[i] if i < len(starts) else None, p)
            for i, p in enumerate(paras)]


def merge_spurious(paras):
    """Merge fake page-break paragraph splits (page-initial words carry a
    spurious paragraphStart=1). Genuine paragraphs never end on a lowercase
    letter; headings (ALL-CAPS or both sides short) are protected."""
    merged = []
    for off, p in paras:
        if merged and p:
            pt, ph = merged[-1][1], p
            if (((pt[-1].isascii() and pt[-1].islower())
                 or (ph[0].isascii() and ph[0].islower()))
                    and not ph[:40].isupper()
                    and not (len(pt) < 80 and len(ph) < 80)):
                merged[-1] = (merged[-1][0], pt + " " + ph)
                continue
        merged.append((off, p))
    return merged


def para_index(paras, offset, tol=60):
    """Index of the paragraph whose start best matches offset."""
    best, best_d = None, 10**9
    for i, (off, _) in enumerate(paras):
        if off is None:
            continue
        d = abs(off - offset)
        if d < best_d:
            best, best_d = i, d
        if off > offset + tol:
            break
    return best if best_d <= tol else None


def chapter_boundaries(res, full_name, n_chapters, book_start):
    """Ordered chapter-start offsets (len == n_chapters) from milestones.

    Duplicate chapter milestones occur (mis-tagged cross-references); the
    verse-1 milestone of the same chapter disambiguates: the real chapter
    heading sits within a few hundred chars of verse 1. Selection proceeds
    in chapter order, always >= prev + 500 chars."""
    chap = [m for m in MAP[res]["chap"]
            if m["l"] == f"{full_name} {int(m['r'].split('.')[2])}"
            and m["o"] >= book_start]
    by_num = {}
    for m in chap:
        num = int(m["r"].split(".")[2])
        if 1 <= num <= n_chapters:
            by_num.setdefault(num, []).append(m["o"])
    v1 = {}
    for m in MAP[res]["v1"]:
        parts = m["r"].split(".")
        if len(parts) >= 4:
            num = int(parts[2])
            if m["l"].startswith(full_name) and 1 <= num <= n_chapters:
                v1[num] = min(v1.get(num, 10**12), m["o"])
    bounds, missing, prev = [], [], book_start
    for n in range(1, n_chapters + 1):
        cands = by_num.get(n) or ([v1[n]] if n in v1 else [])
        if not cands:
            missing.append(n)
            continue
        t = v1.get(n)
        cands = sorted(cands, key=lambda c: (abs(c - t) if t is not None else 0, c))
        pick = next((c for c in cands if c >= prev + 500), cands[-1])
        bounds.append(pick)
        prev = pick
    if missing:
        print(f"    WARN chapters missing milestones: {missing}")
    return bounds, missing


def book_start_offset(res, osis, full_name, toc, single):
    if single:
        start = next((e["o"] for e in toc if e["t"] == "Introduction"), None)
        if start is None:
            start = toc[2]["o"] if len(toc) > 2 else toc[0]["o"]
        return start
    hint = ARTICLE_HINTS.get(osis, full_name)
    art = [e for e in toc if hint in e["t"]]
    return art[0]["o"] if art else None


SDG = re.compile(r"(?i)^soli deo gloria[.!?]?$")  # Lenski's per-epistle outro


def find_sdg(paras):
    """Indices of standalone 'Soli Deo Gloria' outro paragraphs. Counts match
    the book count in every resource, so this is a reliable book boundary."""
    return [i for i, (_, p) in enumerate(paras) if SDG.match(p)]


def build_book(res, osis, full_name, n_chap, paras, i0, sdg, toc, single):
    """Assemble one book. i0 = paragraph index of this book's start (title
    block); the previous book ends at its own 'Soli Deo Gloria' paragraph."""
    if n_chap == 1:
        idx = [i0]  # whole article is chapter 1 (title+intro+body)
    else:
        bounds, missing = chapter_boundaries(res, full_name, n_chap,
                                             paras[i0][0])
        idx = []
        for b in bounds:
            i = para_index(paras, b)
            if i is None or i < i0:
                print(f"    WARN chapter boundary {b} unresolved for {osis}")
                return None
            idx.append(i)
    # chapters must be strictly increasing; dedupe snapped duplicates
    clean = []
    for i in idx:
        if clean and i <= clean[-1]:
            continue
        clean.append(i)
    if len(clean) != n_chap:
        print(f"    WARN {osis}: {len(clean)}/{n_chap} usable boundaries")

    # this book ends at its own outro (kept); the next book starts after it
    nxt_sdg = next((s for s in sdg if s > clean[-1]), None)
    i_book_end = nxt_sdg + 1 if nxt_sdg is not None else len(paras)
    if i_book_end <= clean[0]:
        i_book_end = len(paras)

    chapters = {}
    for ci, i in enumerate(clean):
        i_end = clean[ci + 1] if ci + 1 < len(clean) else i_book_end
        body = "\n\n".join(p for _, p in paras[i:i_end] if p)
        if ci == 0:
            # intro = this book's own front matter (title + INTRODUCTION),
            # i.e. everything from the book start to chapter 1
            intro = "\n\n".join(p for _, p in paras[i0:i] if p)
            body = (intro + "\n\n" + body).strip()
        chapters[str(ci + 1)] = body
    nxt_start = nxt_sdg + 1 if nxt_sdg is not None else None
    return {"book": osis, "name": full_name, "attribution": ATTRIB,
            "intro": None, "chapters": chapters}, nxt_start


def main():
    manifest = {}
    for res, books in RESOURCE_BOOKS.items():
        print(f"== L{res} ==")
        segs = load_segments(f"{WS}/raw-logos/L{res}.jsonl")
        text, poffs = join_segments(segs)
        paras = merge_spurious(split_paragraphs(text, poffs))
        toc = MAP[res]["toc"]
        single = len(books) == 1
        sdg = find_sdg(paras)
        if len(sdg) < len(books):
            print(f"    WARN {len(sdg)} outro markers for {len(books)} books")
        i0 = None
        for bi, (osis, full_name, n_chap) in enumerate(books):
            if i0 is None:
                # first book in resource: locate via TOC (article or intro)
                start = book_start_offset(res, osis, full_name, toc, single)
                i0 = para_index(paras, start)
                if i0 is None:
                    print(f"  {osis}: FAILED (start {start})")
                    continue
            built = build_book(res, osis, full_name, n_chap, paras, i0,
                               sdg, toc, single)
            if built is None:
                print(f"  {osis}: FAILED")
                i0 = None
                continue
            doc, i0 = built
            if len(doc["chapters"]) != n_chap:
                print(f"  {osis}: chapter count {len(doc['chapters'])} != {n_chap}")
            out = f"{WS}/lenski-json-sword/{osis}.json"
            with open(out, "w", encoding="utf-8") as fh:
                json.dump(doc, fh, ensure_ascii=False, indent=1)
            c1 = doc["chapters"]["1"][:60].replace("\n\n", " ¶ ")
            print(f"  {osis}: {n_chap} ch, "
                  f"{sum(len(c) for c in doc['chapters'].values())} chars | {c1}")
            manifest[osis] = {"name": full_name, "file": f"{osis}.json",
                              "chapters": n_chap,
                              "textChars": sum(len(c) for c in
                                               doc["chapters"].values())}
    mpath = f"{WS}/lenski-json-sword/manifest.json"
    with open(mpath, "w", encoding="utf-8") as fh:
        json.dump(dict(sorted(manifest.items())), fh, ensure_ascii=False,
                  indent=1)
    print(f"\nmanifest: {len(manifest)} books, "
          f"{sum(v['textChars'] for v in manifest.values())} chars")


if __name__ == "__main__":
    main()
