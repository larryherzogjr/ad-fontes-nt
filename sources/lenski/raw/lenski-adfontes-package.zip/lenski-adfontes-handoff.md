# Handoff: Incorporate Lenski's NT Commentary into Ad Fontes

**For:** Codex (agent maintaining ad-fontes.app)
**From:** Research + data-prep session, 2026-10-08
**Owner:** Larry Herzog Jr. (Ordinary Means)

---

## 1. Objective

Add R. C. H. Lenski's *The Interpretation of the New Testament* to ad-fontes.app
as (a) a commentary pane in the reader (routes like `/read/JHN/1`) and (b) a
"Commentaries" collection in the Study Library.

---

## 2. Copyright status — researched, with evidence

Do not re-derive. Verified against U.S. Copyright Office renewal records
(Catalog of Copyright Entries, checked volume by volume):

- **In the EU (where the site is hosted): the entire work is public domain.**
  Lenski died in 1936 → life+70 → PD in the EU since 2007-01-01. Germany's
  rule-of-the-shorter-term does not revive protection because the U.S. term
  (below) is longer, not shorter. Serving the full text from the European
  origin is legally clean.
- **In the U.S.: mostly still copyrighted.** Renewals were filed by the widow
  Emma H. Lenski and the children (renewal claimants) between 1961 and 1970:

  | Volume | Original © | Renewal # | U.S. PD date |
  |---|---|---|---|
  | Matthew | 1932 | **none on record** | already PD (since 1961) |
  | Mark + Luke | 1934-01-09 | R289157 | 2030-01-01 |
  | Acts | 1934-09-27 | R298121 | 2030-01-01 |
  | Revelation | 1935-04-01 | R310063 | 2031-01-01 |
  | 1–2 Corinthians | 1935-10-24 | R310068 | 2031-01-01 |
  | Romans | 1936-07-22 | R328247 | 2032-01-01 |
  | Galatians–Phil | 1937-02-16 | R348317 | 2033-01-01 |
  | Colossians–Phlm | 1937-10-18 | R348322 | 2033-01-01 |
  | Hebrews–James | 1938-04-28 | R376018 | 2034-01-01 |
  | Peter–Jude | 1938-05-02 | R376017 | 2034-01-01 |
  | John | 1943-03-01 | R495942 | 2039-01-01 |

### Serving constraints (honor these)

- Keep commentary content **served from the European origin**, and **exclude
  commentary routes from US-edge CDN full-body caching** if the CDN caches
  response bodies. Static assets (JS/CSS/fonts) are unaffected.
- Show this attribution in the resource's About panel:
  > R. C. H. Lenski, *The Interpretation of the New Testament*
  > (Columbus: Wartburg Press / Minneapolis: Augsburg, 1932–1946).
  > Public domain in the EU.
- **Provenance:** the delivered text was extracted from the owner's own
  Logos subscription (publisher edition of the work) at the owner's explicit
  direction; do not substitute text from other transcriptions without
  re-running the QA in §5.

---

## 3. Delivered data — `lenski-json/` (all 27 books, single source)

**Source (final): the owner's Logos web app** (app.logos.com, resources
`LLS:LENSKI01` … `LLS:LENSKI12`, i.e. R. C. H. Lenski, *The Interpretation of
the New Testament*, Augsburg edition), extracted 2026-10-08 with the owner's
authorization via Logos's own `canvas/wordshapedata` rendering API (the app
renders to canvas, so no DOM text exists; the endpoint returns every word
token with stream offsets, punctuation, and paragraph-start flags). All 27
books come from this one publisher-edition source, so formatting is uniform
across the set. Scripts: `extract_logos_lenski.py` (batch page puller),
`build_all_logos.py` (assembler: paragraph reconstruction from
`paragraphStart=1` style flags, book/chapter segmentation at milestone and
`Soli Deo Gloria` outro offsets), `crosscheck.py` (validation) — all included.

**Why not the earlier SWORD-based set:** the first delivery was built from
SermonIndex's SWORD module (`silenski.zip`, OSIS XML → `convert_sword.py`)
plus PHM/REV from Logos. The SWORD text is an independent transcription with
truncated/paraphrased introduction material and scattered wording drift (see
QA). The SWORD-derived set is **retained only as a cross-check reference** in
`lenski-json-previous/`; do not ship it.

Attempts that remain dead ends, for the record:
1. Internet Archive full-text OCR — scans (e.g. `interpretationof0012rchl`)
   are lending-locked (`_djvu.txt`/`.pdf`/`.epub` all `private: true`;
   LCP-DRM copies require a logged-in borrow).
2. Wayback Machine copy of the original source site
   (`217.23.15.100/~bibledat/lenski/`) — `web.archive.org` replay still
   "Temporarily Offline" as of the retry; archive.today (no captures),
   arquivo.pt (empty), the original IP (dead), Bible Analyzer (no Lenski),
   StudyLight (bot-blocked) also ruled out.

**Extraction caveats (uniform across all 27 books):**
- Paragraphs were reconstructed from the renderer's `paragraphStart=1` style
  flags; spurious page-break flags were merged back (rule: a genuine
  paragraph never ends on a lowercase letter; ALL-CAPS headings and short
  pairs are protected). Around Greek tokens a few 2–23 char inter-token gaps
  (spacing/dashes) could not be recovered — estimate < 0.02% of characters,
  always adjacent to Greek words.
- Verse paragraphs start with an arabic number + right paren: `1) To the
  angel …`; chapter headings are `CHAPTER 1` (arabic). This is now uniform
  across all 27 books.
- Book segmentation uses Lenski's per-epistle `Soli Deo Gloria` outro line
  (one per book, verified in every volume) and bible chapter milestones;
  duplicate/mis-tagged milestones (found in 1 Corinthians) were resolved
  against verse-1 milestones.

`manifest.json` is updated; all 27 books are in `lenski-json/`.

### JSON schema (exactly as delivered)

One file per book: `lenski-json/<OSIS>.json` (e.g. `JHN.json`).

```json
{
  "book": "JHN",
  "name": "John",
  "attribution": "R. C. H. Lenski, The Interpretation of the New Testament (Wartburg Press / Augsburg, 1932–1946). Public domain in the EU.",
  "intro": null,
  "chapters": {
    "1": "CHAPTER 1\n\nTHE PROLOG\n\nThe Word Became Flesh, 1–18\n\nJohn’s Gospel begins …\n\n1) In the beginning was the Word …\n\n2) And now the three foregoing …",
    "2": "…"
  }
}
```

- `book` — OSIS book id (MAT, MRK, LUK, JHN, ACT, ROM, 1CO, 2CO, GAL, EPH,
  PHP, COL, 1TH, 2TH, 1TI, 2TI, TIT, PHM, HEB, JAS, 1PE, 2PE, 1JN, 2JN, 3JN,
  JUD, REV) — complete 27-book New Testament.
- `intro` — always `null` in this dataset (front matter lives inside
  chapter 1, per book: the title block, `INTRODUCTION` section where the
  volume has one, and the chapter text; the whole book ends with Lenski's
  `Soli Deo Gloria` line).
- `chapters` — object keyed by **1-based chapter number as a string**.
  Value: the full chapter commentary as plain text.
- **Paragraphs are separated by `\n\n`.** Paragraph starts carry structure:
  chapter heading (`CHAPTER 1`), section headings (e.g. `The Word Became
  Flesh, 1–18`), and **verse comments that begin with the verse number**:
  `1) In the beginning…` (arabic number + right paren, uniformly across all
  27 books). Verse-level splitting is reliable: split on `^\d{1,3}\)` at
  paragraph starts, with the leading number = start verse; run until the
  next numbered paragraph (section headings like `The Word Became Flesh,
  1–18` give explicit ranges; unnumbered tail paragraphs belong to the
  current verse).
- Greek text is inline Unicode (polytonic), e.g. `κατά`, `ἐν ἀρχῇ`, from
  the publisher's typesetting (no OCR).

`lenski-json/manifest.json` lists every book with chapter count and character
count. Total: ~21.9 M chars across 27 books (~3.9 M words).

### Regenerating / extending

- `extract_logos_lenski.py` — app.logos.com `canvas/wordshapedata` → JSONL
  page segments for all 12 LENSKI resources (needs the owner's logged-in
  Chrome session via WebBridge; batch of 10 pages per call).
- `build_all_logos.py` — assembles all 27 books from those segments +
  TOC/milestone map (TOC + `milestonesInRanges` dumps; resource versions
  2017-03/04; book numbers 61–87; `Soli Deo Gloria` outro paragraphs = one
  per book).
- `crosscheck.py` — per-chapter token-multiset coverage against the
  SWORD-derived reference set.
- `convert_sword.py` — SWORD zcom → JSON (regenerates the *reference* set
  only). `extract_lenski.py` — theWord `.cmt.twm` → JSON (Matthew–Colossians
  only; kept for cross-checking). `build_phm_rev.py` — earlier per-book
  Logos assembler, superseded by `build_all_logos.py`.
- SWORD module layout (reference set): `nt.bzz` = one zlib stream per book
  (walk with `zlib.decompressobj`, next stream begins right after
  `unused_data`; note a 1 KB zero pad at EOF and one mid-file orphan stream
  = 2John 14 tail, which `convert_sword.py` merges automatically).

---

## 4. Integration notes

1. **Reader commentary pane:** for the passage in view, fetch the book JSON,
   split the chapter into verse ranges (rule above), and show the entries
   overlapping the current verse. Lazy-load per book.
2. **Library collection:** "Commentaries → Lenski on the New Testament",
   per-book browsing, full-text search (the JSON is plain text; index with the
   repo's existing search approach).
3. **Attribution** from §2 in the About panel.

## 5. QA status

- [x] All 27 books present with complete chapter counts (Matt 28 … Jude 1).
- [x] Book boundaries verified via per-epistle `Soli Deo Gloria` outro
      paragraphs (one per book in every volume) + bible chapter milestones.
- [x] **Cross-validated against the independent SWORD transcription**
      (`crosscheck.py`, token-multiset per chapter): 97.5% of Logos tokens
      appear in the SWORD set overall; **99.6% for chapters 2+**. The ~2.5%
      gap concentrates in chapter 1, where the SWORD transcription truncates
      Lenski's introduction material (the Logos publisher edition is
      complete) — manual inspection of the longest divergent runs in
      mid-book chapters (EPH 3, ACT 26, MAT 5, HEB 8, ROM 5, 1CO 12) found
      only genuine Lenski prose on the Logos side, i.e. S-side defects.
- [x] Verse-number paragraph starts verified (`1)` format, uniform).
- [x] Greek text present and readable (polytonic Unicode, publisher
      typesetting — no OCR artifacts).
- [x] Two assembly defects found by the cross-check and fixed: last-chapter
      bleed into the next book's front matter, and empty 1CO ch5 caused by
      duplicate chapter milestones (resolved against verse-1 milestones).
- [ ] Commentary routes excluded from US-edge CDN body caching.
- [ ] Attribution visible in UI.

## 6. Out of scope

Other commentaries, OT works, paywalling.
