#!/usr/bin/env python3
"""Extract Lenski commentary text from app.logos.com (web) via its own
canvas/wordshapedata API, using the logged-in Chrome session through the
Kimi WebBridge daemon (http://127.0.0.1:10086).

Reconstruction rules (verified empirically 2026-10-08):
- Each word token carries indexedOffset/indexedLength and htmlText; htmlText
  is the exact stream substring and includes attached punctuation.
- wordStyles[styleIndex] contains `paragraphStart=1` for paragraph-initial
  words -> paragraphs are joined with "\n\n", intra-paragraph with " ".
- Gap between consecutive word offsets is always 1 (space lives in the gap
  char); verified max gap == 1 across sample pages.

Output: JSONL segments {batch, refs, n, first, last, maxGap, poffs, text}
"""
import json
import sys
import time
import urllib.request

DAEMON = "http://127.0.0.1:10086/command"
SESSION = "lenski-logos"

IN_PAGE = """
(async()=>{
  const refs = %s;
  const rid = %s;
  const r = await fetch('/api/app/canvas/wordshapedata/references',{
    method:'POST',
    headers:{'Content-Type':'application/json',Accept:'application/json'},
    body:JSON.stringify({references:refs,resourceId:rid})});
  if(!r.ok) return JSON.stringify({error:r.status});
  const j = await r.json();
  const trs = j.wordTextRanges||[];
  const styles = j.wordStyles||[];
  const seen = new Set(); const all = [];
  for(const t of trs){ for(const w of t.words){
    if(seen.has(w.indexedOffset)) continue; seen.add(w.indexedOffset);
    all.push([w.indexedOffset, w.htmlText,
      (styles[w.styleIndex]||'').includes('paragraphStart=1')?1:0]);
  }}
  all.sort((a,b)=>a[0]-b[0]);
  let text=''; const poffs=[]; let maxGap=0;
  for(let i=0;i<all.length;i++){ const w=all[i];
    if(i>0){ const gap=w[0]-(all[i-1][0]+all[i-1][1].length);
      if(gap>maxGap) maxGap=gap; }
    if(i===0){ text=w[1]; if(w[2]) poffs.push(w[0]); }
    else if(w[2]){ text+='\\n\\n'+w[1]; poffs.push(w[0]); }
    else text+=' '+w[1];
  }
  return JSON.stringify({n:all.length, first:all.length?all[0][0]:null,
    last:all.length?all[all.length-1][0]:null, maxGap, text, poffs});
})()
"""


def evaluate(code: str, retries: int = 3) -> dict:
    body = json.dumps({"action": "evaluate", "args": {"code": code},
                       "session": SESSION}).encode()
    for attempt in range(retries):
        try:
            req = urllib.request.Request(DAEMON, data=body,
                                         headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=120) as resp:
                out = json.loads(resp.read())
            if out.get("ok"):
                val = out["data"]["value"]
                return json.loads(val)
            err = out.get("error", {})
            if attempt == retries - 1:
                raise RuntimeError(f"daemon error: {err}")
        except (urllib.error.URLError, TimeoutError, RuntimeError) as e:
            if attempt == retries - 1:
                raise
            time.sleep(2 * (attempt + 1))
    raise RuntimeError("unreachable")


def extract(rid: str, page_from: int, page_to: int, out_path: str,
            batch: int = 10) -> None:
    pages = list(range(page_from, page_to + 1))
    with open(out_path, "a", encoding="utf-8") as fh:
        for i in range(0, len(pages), batch):
            refs = [f"page.{p}" for p in pages[i:i + batch]]
            code = IN_PAGE % (json.dumps(refs), json.dumps(rid))
            res = evaluate(code)
            if "error" in res:
                raise RuntimeError(f"batch {refs[0]}..{refs[-1]}: HTTP {res['error']}")
            rec = {"batch": i // batch, "refs": refs, **res}
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            fh.flush()
            print(f"batch {rec['batch']:>3}: pages {refs[0]}..{refs[-1]} "
                  f"n={res['n']} maxGap={res['maxGap']} chars={len(res['text'])}",
                  flush=True)
            time.sleep(0.35)


if __name__ == "__main__":
    rid = sys.argv[1]
    p_from, p_to = int(sys.argv[2]), int(sys.argv[3])
    out = sys.argv[4]
    extract(rid, p_from, p_to, out)
