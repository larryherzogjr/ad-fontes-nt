#!/usr/bin/env python3
"""Convert the SermonIndex SWORD zcom module (silenski) to per-book JSON.

The bzz file holds one zlib stream per NT book (BlockType=BOOK). Each
stream is OSIS XML fragments: <chapter osisID="Matt.1"/> boundaries and
<div sID/eID type="x-p"/> paragraph containers. Output: one JSON per
book with paragraphs per chapter. NOTE: Revelation is absent from the
source module; Philemon is present.
"""
import zlib, re, json, os

BZZ = 'silenski_sword/modules/comments/zcom/silenski/nt.bzz'
OUT = 'lenski-json-sword'

OSIS2REF = {
    'Matt': 'MAT', 'Mark': 'MRK', 'Luke': 'LUK', 'John': 'JHN', 'Acts': 'ACT',
    'Rom': 'ROM', '1Cor': '1CO', '2Cor': '2CO', 'Gal': 'GAL', 'Eph': 'EPH',
    'Phil': 'PHP', 'Col': 'COL', '1Thess': '1TH', '2Thess': '2TH', '1Tim': '1TI',
    '2Tim': '2TI', 'Titus': 'TIT', 'Heb': 'HEB', 'Jas': 'JAS', '1Pet': '1PE',
    '2Pet': '2PE', '1John': '1JN', '2John': '2JN', '3John': '3JN', 'Jude': 'JUD',
}
BOOKNAMES = {
    'MAT': 'Matthew', 'MRK': 'Mark', 'LUK': 'Luke', 'JHN': 'John', 'ACT': 'Acts',
    'ROM': 'Romans', '1CO': '1 Corinthians', '2CO': '2 Corinthians',
    'GAL': 'Galatians', 'EPH': 'Ephesians', 'PHP': 'Philippians', 'COL': 'Colossians',
    '1TH': '1 Thessalonians', '2TH': '2 Thessalonians', '1TI': '1 Timothy',
    '2TI': '2 Timothy', 'TIT': 'Titus', 'PHM': 'Philemon', 'HEB': 'Hebrews',
    'JAS': 'James', '1PE': '1 Peter', '2PE': '2 Peter', '1JN': '1 John',
    '2JN': '2 John', '3JN': '3 John', 'JUD': 'Jude', 'REV': 'Revelation',
}

def get_blocks(path):
    data = open(path, 'rb').read()
    blocks, pos = [], 0
    while pos < len(data) - 100:
        d = zlib.decompressobj()
        try:
            out = d.decompress(data[pos:])
        except Exception:
            nxt = data.find(b'\x78\x9c', pos + 1)
            if nxt < 0:
                break
            pos = nxt
            continue
        if not out:
            break
        consumed = len(data[pos:]) - len(d.unused_data)
        blocks.append(out.decode('utf-8', errors='replace'))
        pos += consumed
    return blocks

def split_chapters(text):
    """Return {chapterNumber: [paragraphs]} from one book's OSIS fragment."""
    chapters = {}
    cur_ch = None
    cur_paras = []
    # tokenize by chapter start tags and paragraph divs
    tokens = re.split(r'(<chapter osisID="[^"]+"[^>]*/>|<div sID="[^"]+" type="x-p"/>|<div eID="[^"]+" type="x-p"/>|</?div[^>]*>)', text)
    in_para = False
    buf = ''
    for tok in tokens:
        if tok.startswith('<chapter osisID="'):
            if cur_ch is not None:
                if buf.strip():
                    cur_paras.append(buf)
                chapters[cur_ch] = [p.strip() for p in cur_paras if p.strip()]
            cur_ch = int(re.search(r'osisID="[^.]+\.(\d+)"', tok).group(1))
            cur_paras = []
            buf = ''
            in_para = False
        elif tok == '<div sID="gen4" type="x-p"/>' or (tok.startswith('<div sID=') and 'type="x-p"' in tok):
            if buf.strip():
                cur_paras.append(buf)
            buf = ''
            in_para = True
        elif tok.startswith('<div eID=') and 'type="x-p"' in tok:
            if buf.strip():
                cur_paras.append(buf)
            buf = ''
            in_para = False
        elif tok.startswith('<'):
            continue          # other tags (book divs, milestones)
        else:
            if in_para or buf:
                buf += tok
            elif tok.strip() and cur_ch is not None:
                buf = tok     # text before any para marker in chapter
    if cur_ch is not None:
        if buf.strip():
            cur_paras.append(buf)
        chapters[cur_ch] = [p.strip() for p in cur_paras if p.strip()]
    return chapters

def main():
    os.makedirs(OUT, exist_ok=True)
    blocks = get_blocks(BZZ)
    print(f'{len(blocks)} streams')
    manifest = {}
    joined_extra = None
    for text in blocks:
        m = re.match(r'\s*<div osisID="([A-Za-z0-9]+)"', text)
        if not m:
            if joined_extra is None:
                joined_extra = text       # orphan continuation block (2John 14)
            else:
                joined_extra += text
            continue
        osis = m.group(1)
        ref = OSIS2REF.get(osis)
        if not ref:
            print('  unknown book', osis)
            continue
        chapters = split_chapters(text)
        doc = {
            'book': ref,
            'name': BOOKNAMES[ref],
            'attribution': ('R. C. H. Lenski, The Interpretation of '
                            'the New Testament (Wartburg Press / Augsburg, '
                            '1932–1946). Public domain in the EU.'),
            'intro': None,
            'chapters': {str(k): '\n\n'.join(v) for k, v in sorted(chapters.items())},
        }
        path = os.path.join(OUT, f'{ref}.json')
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(doc, f, ensure_ascii=False, indent=1)
        manifest[ref] = {
            'name': BOOKNAMES[ref],
            'file': f'{ref}.json',
            'chapters': len(chapters),
            'textChars': sum(len(t) for t in doc['chapters'].values()),
        }
        print(f"{ref:4s} {BOOKNAMES[ref]:18s} chapters={len(chapters):3d} "
              f"chars={manifest[ref]['textChars']:8d}")
    if joined_extra:
        print('NOTE orphan block kept in _orphan.txt (2John 14 tail)')
        with open(os.path.join(OUT, '_orphan.txt'), 'w', encoding='utf-8') as f:
            f.write(joined_extra)
    with open(os.path.join(OUT, 'manifest.json'), 'w', encoding='utf-8') as f:
        json.dump(manifest, f, ensure_ascii=False, indent=1)

if __name__ == '__main__':
    main()
