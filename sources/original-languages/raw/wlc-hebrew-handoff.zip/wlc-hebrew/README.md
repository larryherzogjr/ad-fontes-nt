# WLC Hebrew Bible — Masoretic Text (Public Domain)

The Hebrew Old Testament (Tanakh) for inclusion in Ad Fontes: the
**Westminster Leningrad Codex**, the digital transcription of the Leningrad
Codex (1008 CE) — the oldest complete manuscript of the Hebrew Bible and the
base text of Biblia Hebraica Stuttgartensia.

## License

- The **text of the Leningrad Codex is public domain**.
- This digital edition is the **Open Scriptures Hebrew Bible** project
  (github.com/openscriptures/morphhb): text public domain; the project's
  lemma/morphology tagging is CC BY 4.0. This bundle contains **text only**
  (no tagging), so no attribution is legally required — but crediting
  "Westminster Leningrad Codex / Open Scriptures Hebrew Bible" in an about
  page is good practice.
- Do NOT substitute BHS/BHQ digital files: those *editions* are copyrighted
  (Deutsche Bibelgesellschaft), even though they print essentially this text.

## Files

- `json/<CODE>.json` — 39 books, shape:
  `{"code", "book", "language": "he", "direction": "rtl", "translation", "chapters": {"<ch>": {"<v>": "<text>"}}}`
- `text/<CODE>.txt` — human-readable rendering (Hebrew, right-to-left).
- `manifest.json` — book index. **Total: 39 books, 23,213 verses.**

## Text characteristics

- Fully **pointed**: vowels (niqqud) and cantillation marks (teamim) are
  included, exactly as encoded by OSHB.
- Verse text is space-separated words. **Maqqef is encoded as `/`** between
  word parts (OSHB convention, e.g. `וַ/יְהִ֗י`) — strip or replace it for
  display if desired.

## Versification — read before integrating

- **Psalm superscriptions are numbered verse 1** in this tradition. E.g.
  Psalm 3:1 = the superscription ("מזמור לדויד..."), Psalm 3:2 = what English
  Bibles call 3:1. To display alongside KJV-style translations, shift Psalm
  verse numbers by one or treat superscriptions as titles.
- Verse numbering is otherwise standard Masoretic (BHS chapter/verse).
- **Daniel is the 12-chapter Hebrew-Aramaic book** — no Susanna/Bel. Those
  exist in Ad Fontes' Greek (Septuagint) material, not here.
- Masoretic paragraph markers (petucha/setuma, encoded as verse 0 in the
  source) are excluded from this bundle.

## Rebuild

`parse_wlc.py` (one directory up in the workspace) regenerates this bundle
from the source repo archive (`morphhb.zip`, Open Scriptures Hebrew Bible).
