# Clementine Vulgate — Latin (Public Domain)

The Latin Bible for inclusion in Ad Fontes: the **Sixto-Clementine Vulgate**
(edition of 1592, third printing 1598), the official Latin Bible of the
Catholic Church from 1592 until 1979. Fully **public domain**.

## License

Public domain by age. No attribution legally required; crediting
"Biblia Sacra Vulgata (Sixto-Clementine, 1592/1598)" is good practice.

- **Base text:** CVUL module (Clementine Text Project transcription,
  distributed via ph4.org).
- **Patched books:** Judith, Wisdom, and the complete Greek Esther were
  missing or defective in the module; they are patched from the Clementine
  Text Project transcription on Latin Wikisource (*Vulgata Clementina*, 1598
  edition) — same edition, same provenance.
- Do NOT substitute the Stuttgart Vulgate (Weber-Gryson, copyrighted) or the
  Nova Vulgata (1979, copyrighted) — both are common online and both are
  off-limits.

## Files

- `json/<CODE>.json` — 73 books (OT incl. deuterocanon + full NT), shape:
  `{"code", "book", "language": "la", "direction": "ltr", "translation", "chapters": {"<ch>": {"<v>": "<text>"}}}`
- `text/<CODE>.txt` — human-readable rendering.
- `manifest.json` — book index. **Total: 73 books, 35,810 verses.**

## Canon and versification — read before integrating

- **Deuterocanon included:** Tobit, Judith, Greek Esther (16 chapters — the
  additions are integrated as Esther 10:4–16, Vulgate order), Wisdom, Sirach,
  Baruch (the Epistle of Jeremiah is **Baruch chapter 6**), 1 & 2 Maccabees.
  This matches the Clementine canon.
- **Absent from the Clementine canon** (so not here): Psalm 151, Prayer of
  Manasseh. The Clementine appendix books 3 & 4 Esdras (= English 1 & 2
  Esdras) are **not present** in this digital module — if Ad Fontes wants
  them, they must be sourced separately.
- **Psalms follow the Vulgate/Greek numbering**: Psalm 9 combines MT 9+10;
  from Psalm 10 onward Vulgate numbers run one behind the Hebrew/English
  tradition (Vulgate Ps 147 = MT Ps 146+147 combined). Psalter is the
  Gallicanum.
- **Old Testament book order** is the Vulgate order (Samuel/Kings = I–IV
  Regum, Chronicles = Paralipomenon, Ezra-Nehemiah = I–II Esdrae); file
  codes follow the standard USFM names (1SA, 1KI, EZR, NEH) for
  interoperability.
- Verse numbering occasionally differs from both the Hebrew and the LXX;
  spot-check against Ad Fontes' other texts before enabling parallel display.

## Rebuild

`parse_vulgate.py` (one directory up in the workspace) regenerates this
bundle from the CVUL module, re-fetching the three patched books from Latin
Wikisource.
